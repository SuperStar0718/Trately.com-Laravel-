<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header pb-0 px-3">

            <?php echo e(__('Write Note')); ?>



        </div>
        <form action="/save-note" method="post">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label"><?php echo e(__('Title')); ?></label>
                    <input type="text" name="title" <?php if(!empty($note)): ?> value="<?php echo e($note->title); ?>"<?php endif; ?> class="form-control" id="exampleFormControlInput1" >
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label"> <?php echo e(__('Topic/Subject')); ?></label>
                    <input type="text" name="topic" <?php if(!empty($note)): ?> value="<?php echo e($note->topic); ?>"<?php endif; ?>  class="form-control" id="exampleFormControlInput1" >
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label"><?php echo e(__('Write Notes')); ?></label>
                    <textarea class="form-control" name="notes" id="notes" rows="20"><?php if(!empty($note)): ?><?php echo $note->notes; ?><?php endif; ?></textarea>
                </div>
                <?php echo csrf_field(); ?>
                <?php if($note): ?>
                    <input type="hidden" name="id" value="<?php echo e($note->id); ?>">
                <?php endif; ?>
                <button class="btn btn-primary" type="submit"><?php echo e(__('Save')); ?></button>
            </div>

        </form>


    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        tinymce.init({
            selector: '#notes',


            plugins: [
                'insertdatetime media table paste code help wordcount'
            ],

            min_height: 500,
            max_height: 800,
            convert_newlines_to_brs: false,
            statusbar: false,
            relative_urls: false,
            remove_script_host: false,
            language: 'en',




        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/actions/add-note.blade.php ENDPATH**/ ?>