<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <?php echo e(__('Set Your Goal')); ?>


        </div>
        <div class="card-body">
            <form action="/save-goal" method="post">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="example-text-input" class="form-control-label">
                       <?php echo e(__('Whats your Goal/ Title')); ?>

                    </label><span class="text-danger">*</span>
                    <input class="form-control"  type="text" name="name" <?php if(!empty($goal)): ?> value="<?php echo e($goal->name); ?>" <?php endif; ?> id="name" >
                </div>

                <div class="form-group">
                    <label for="example-date-input" class="form-control-label">
                        <?php echo e(__('By when you want to achieve it')); ?>


                    </label><span class="text-danger">*</span>
                    <input class="form-control" name="date" id="date"

                           <?php if(!empty($goal)): ?>
                        value="<?php echo e($goal->date); ?>"
                    <?php else: ?>
                        value="<?php echo e(date('Y-m-d')); ?>"
                        <?php endif; ?>">
                </div>
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1">
                           <?php echo e(__('Describe why its your goal')); ?>

                        </label>
                        <span class="text-danger">*</span>
                        <textarea class="form-control" name="description" id="description" rows="3"><?php if(!empty($goal)): ?> <?php echo e($goal->description); ?><?php endif; ?>  </textarea>
                    </div>


                    <?php if($goal): ?>
                        <input type="hidden" name="id" value="<?php echo e($goal->id); ?>">
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn bg-gradient-secondary">
                        <?php echo e(__('Save')); ?>


                    </button>
                <button type="button" class="btn bg-gradient-secondary">
                    <?php echo e(__('Close')); ?>


                </button>
            </form>


        </div>

    </div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        "use strict"
        $(function () {


            flatpickr("#date", {

                dateFormat: "Y-m-d",
            });



        });




    </script>

    <script>
        tinymce.init({
            selector: '#description',


            plugins: 'table,code',


        });
    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/goals/set-goal.blade.php ENDPATH**/ ?>