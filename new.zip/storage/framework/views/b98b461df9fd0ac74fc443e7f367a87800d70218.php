<?php $__env->startSection('content'); ?>

    <div class="row d-print-none">


        <div class="col text-center">
            <h5 class="mb-2 text-secondary fw-bolder">
                <?php echo e(__('Porter\'s Five Forces Model of')); ?>

                <?php if(!empty($model)): ?>
                    <?php echo e($model->company_name); ?>

                <?php endif; ?>

            </h5>
        </div>

    </div>
    <div class="row mt-3">
        <div class="col-md-1 text-center d-print-none">


            <a href="/new-porter?id=<?php echo e($model->id); ?>" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Edit">
                <i class="fas fa-pen p-2"></i>
            </a>
            <a href="#" onclick="window.print()" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="Print">
                <i class="fas fa-print p-2"></i>
            </a>
            <a href="/porter-models" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="List">
                <i class="fas fa-ellipsis-h p-2"></i>
            </a>
        </div>
        <div class="col-md-11">
            <div class="card-group">

                <div class="card">

                    <div class="card-header fw-bolder text-center text-white bg-lightblue">

                        <?php echo e(__('Threat of New Entry')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->entrants); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder text-center text-white bg-info">

                        <?php echo e(__(' Bargaining Power of Suppliers')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->suppliers); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder text-center text-white  bg-darkblue">

                        <?php echo e(__('Rivalry Among Existing Competitors')); ?>

                    </div>
                    <div class="card-body">
                        <p>  <?php if(!empty($model)): ?>
                                <?php echo clean($model->rivals); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder  text-center bg-info text-white">

                        <?php echo e(__('Bargaining Power of Buyers')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->customers); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder text-center text-white  bg-lightblue">

                        <?php echo e(__('Threat of Substitute')); ?>

                    </div>
                    <div class="card-body">
                        <p>  <?php if(!empty($model)): ?>
                                <?php echo clean($model->substitute); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/porter/view.blade.php ENDPATH**/ ?>