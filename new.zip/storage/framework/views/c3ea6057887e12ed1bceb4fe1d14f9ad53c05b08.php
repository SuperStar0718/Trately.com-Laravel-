<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="card">
        <div class="card-header">
            <h4> Journal of  - <?php echo e($journal->date); ?></h4>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">
                            <h5>2 things I am grateful for</h5>



                        </li>
                        <p> <?php echo $journal->grateful; ?></p>

                    </div>
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">    <h5>What would make me feel great today</h5>


                        </li>
                        <p> <?php echo $journal->feeling; ?></p>


                    </div>


                </div>
                <div class="row">
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">     <h5>Daily affirmations</h5>


                        </li>
                        <p> <?php echo $journal->affirmations; ?></p>

                    </div>
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">       <h5>Favorite things of my day</h5>



                        </li>
                        <p> <?php echo $journal->fav_things; ?></p>


                    </div>


                </div>
                <div class="row">
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">    <h5>What can i do today that will bring me closer to my dream</h5>

                        </li>
                        <p><?php echo $journal->dream; ?></p>

                    </div>
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">   <h5>What positive habit i have developed</h5>

                        </li>
                        <p> <?php echo $journal->habit; ?></p>


                    </div>


                </div>
                <div class="row">
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">    <h5>I should not waste time on</h5>

                        </li>
                        <p> <?php echo $journal->dont_waste; ?></p>

                    </div>
                    <div class="col-md-6">

                        <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">   <h5>What are the things i must accomplish today (Non-Negotiable)</h5>


                        </li>
                        <p> <?php echo $journal->must_accomplish; ?></p>


                    </div>


                </div>



            </div>
        </div>
    </div>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/gratitude/view-journal.blade.php ENDPATH**/ ?>