<?php $__env->startSection('content'); ?>


    <div class=" row">
        <div class="col">
            <h5 class=" text-secondary fw-bolder">
                <?php echo e(__('Tasks')); ?>

            </h5>

        </div>

        <div class="col text-end">
            <a  href="/add-task" type="button" class="btn btn-info text-white "><?php echo e(__(' Add To-dos')); ?></a>
        </div>

    </div>





    <div class="row">
        <div class="col-md-8 ">
            <div class="">
                <div class="card-header">
                    <div class="row">



                        <ul class="list-group list-group-flush" data-toggle="checklist">
                            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <li class="list-group-item border-0 flex-column align-items-start ps-0 py-0 mb-3">
                                    <div class="checklist-item checklist-item-primary ps-2 ms-3">
                                        <div class="d-flex align-items-center">
                                            <div class="form-check">
                                                <input class="form-check-input todo_checkbox" type="checkbox"
                                                       data-id="<?php echo e($todo->id); ?>"

                                                       <?php if($todo->completed): ?> checked <?php endif; ?>

                                                >
                                            </div>
                                            <h6 class="mb-0 text-dark font-weight-bold text-sm"><?php echo e($todo->title); ?></h6>
                                            <div class="dropdown float-lg-end ms-auto pe-4">
                                                <a href="javascript:;" class="cursor-pointer" id="dropdownTable2" data-bs-toggle="dropdown" aria-expanded="false">                             <a class="btn btn-link text-dark px-3 mb-0" href="/view-todo/?id=<?php echo e($todo->id); ?>"><i class="fas fa-file-alt text-dark me-2" aria-hidden="true"></i><?php echo e(__('view')); ?></a>

                                                    <a class="btn btn-link text-dark px-3 mb-0" href="/add-task/?id=<?php echo e($todo->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i><?php echo e(__('Edit')); ?></a>

                                                </a>

                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center ms-4 mt-3 ps-1">
                                            <div>
                                                <p class="text-xs mb-0 text-secondary font-weight-bold"><?php echo e(__('Date')); ?></p>
                                                <span class="text-xs font-weight-bolder"><?php echo e($todo->date->format(config('app.date_format'))); ?></span>
                                            </div>

                                        </div>
                                    </div>
                                    <hr class="horizontal dark mt-4 mb-0">
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </ul>

                    </div>

                </div>

            </div>
        </div>

        <div class="col-md-4">
            <div class="card mb-3 mt-lg-0 mt-4">
                <div class="card-body pb-0">
                    <div class="row align-items-center mb-3">
                        <div class="col-9">
                            <h6 class="mb-1 text-purple">
                                <a href="javascript:;">Total Tasks</a>
                            </h6>
                        </div>
                        <div class="col-3 text-end">
                            88
                        </div>
                    </div>


                </div>
            </div>
        </div>



    </div>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script>
    "use strict";

    $(function () {

        $('.todo_checkbox').on('change',function () {
            let that = $(this);
            if(this.checked)
            {
                $.post('/todos/change-status',{
                    id: that.attr('data-id'),
                    status: 'Completed',
                    _token: '<?php echo e(csrf_token()); ?>',
                });
            }
            else{
                $.post('/todos/change-status',{
                    id: that.attr('data-id'),
                    status: 'Not Completed',
                    _token: '<?php echo e(csrf_token()); ?>',
                });
            }
        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/actions/todos.blade.php ENDPATH**/ ?>