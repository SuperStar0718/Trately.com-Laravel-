<?php $__env->startSection('content'); ?>



    <div class="card mb-3 mt-4">
        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">
                    <h6 class="mb-0">Add New Contact</h6>
                </div>
                <div class="col-md-6 text-right">
                    <a class="btn bg-gradient-dark mb-0" href="/people">&nbsp;&nbsp;Go to Contact List</a>
                </div>
            </div>
        </div>
        <div class="card-body  p-3">
            <form method="post" action="/contact">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <div class="form-group">
                    <label for="example-tel-input" class="form-control-label">Audience</label>
                    <select class="form-select" aria-label="Default select example">

                        <option selected>Open this select menu</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-text-input" class="form-control-label">First Name</label>
                            <input class="form-control" name="first_name" type="text" value="John Snow" id="example-text-input">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-text-input" class="form-control-label">Last Name</label>
                            <input class="form-control" name="last_name"type="text" value="John Snow" id="example-text-input">
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label for="example-email-input" class="form-control-label">Email</label>
                    <input class="form-control" name="email" type="email"  id="example-email-input">
                </div>

                <div class="form-group">
                    <label for="example-tel-input" class="form-control-label">Phone</label>
                    <input class="form-control" name="phone_number" type="tel" value="40-(770)-888-444" id="example-tel-input">
                </div>
               <?php echo csrf_field(); ?>
                <button type="Submit" class="btn btn-secondary">Save</button>
                <button type="button" class="btn btn-primary">close</button>


            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/contacts/new-contact.blade.php ENDPATH**/ ?>