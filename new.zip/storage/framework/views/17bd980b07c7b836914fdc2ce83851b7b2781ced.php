<?php $__env->startSection('title',$blog->title); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-header min-vh-80 py-9" style="background-image: url(<?php echo e(PUBLIC_DIR); ?>/uploads/<?php echo e($blog->cover_photo); ?>);">
        <span class="mask bg-gradient-dark opacity-4"></span>
        <div class="container">
            <div class="row justify-content-center">
                <div class="text-center mx-auto">




                </div>
            </div>
        </div>
    </div>



<div class="col-lg-7 mx-auto text-start card card-body blur d-flex justify-content-center mt-lg-5">
    <h2 class="fw-bolder mt-2 mb-4"><?php echo e($blog->title); ?></h2>

    <div class=" d-flex ">
        <?php if(!empty($users[$blog->admin_id]->photo)): ?>
            <img alt="" class=" avatar rounded-circle shadow " src="<?php echo e(PUBLIC_DIR); ?>/uploads/<?php echo e($users[$blog->admin_id]->photo); ?>">
        <?php else: ?>
            <div class="avatar rounded-circle bg-purple-light  border-radius-md p-2">
                <h6 class="text-purple mt-1"><?php echo e($users[$blog->admin_id]->first_name[0]); ?><?php echo e($users[$blog->admin_id]->last_name[0]); ?></h6>
            </div>
        <?php endif; ?>

        <div class="name text-dark ps-2">
            <?php if(!empty($users[$blog->admin_id])): ?>
                <span><?php echo e($users[$blog->admin_id]->first_name); ?> <?php echo e($users[$blog->admin_id]->last_name); ?></span>

            <?php endif; ?>
                <div class="stats text-muted">
                    <small><?php echo e($blog->updated_at->diffForHumans()); ?></small>

                </div>

        </div>


    </div>


        <p class="text-dark">
            <?php echo $blog->notes; ?>

        </p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/frontend/view-blog.blade.php ENDPATH**/ ?>