<?php $__env->startSection('content'); ?>



    <div class=" row mt-1 d-print-none">
        <div class="col">
            <h5 class="text-secondary fw-bolder">
                <?php echo e(__('Startup Canvas of')); ?> <?php echo e($model->company_name); ?>

            </h5>
        </div>
        <div class="col text-end">

            <a href="#" onclick="window.print()"
               class="btn bg-gradient-dark btn-sm add_event waves-effect waves-light"><?php echo e(__('Print')); ?></a>
            <a href="/design-startup-canvas?id=<?php echo e($model->id); ?>"
               class="btn btn-sm btn-warning add_event waves-effect waves-light"><?php echo e(__('Edit')); ?></a>
            <a href="/delete/business-model/<?php echo e($model->id); ?>"
               class="btn btn-sm btn-danger add_event waves-effect waves-light"><?php echo e(__('Delete')); ?></a>
        </div>
    </div>
    <div class="">
        <div class="">
            <p class="text-sm"><?php echo e(__('Company Name')); ?>: <span class="text-dark fw-bolder"><?php echo e($model->company_name); ?></span></p>


            <p class="text-sm"><?php echo e(__('Related Product')); ?>:<span class="text-dark fw-bolder"> <?php if(!empty($products[$model->product_id])): ?>
                        <?php if(isset($products[$model->product_id])): ?>
                            <?php echo e($products[$model->product_id]->title); ?>

                        <?php endif; ?>
                    <?php endif; ?></span></p>
            <p class="text-sm"><?php echo e(__('Designed By')); ?>:<span class="text-purple fw-bolder"> <?php if(isset($users[$model->admin_id])): ?>
                        <?php echo e($users[$model->admin_id]->first_name); ?> <?php echo e($users[$model->admin_id]->last_name); ?>

                    <?php endif; ?></span></p>
            <p class="text-sm"><?php echo e(__('Created At')); ?>:
                <span class="badge bg-secondary"><?php echo e((\App\Supports\DateSupport::parse($model->created_at))->format(config('app.date_format'))); ?></span></p>




            <div class="table-responsive bg-yellow-light">
                <table class="table align-items-center mb-0  table-bordered">
                    <thead>
                    <tr>
                        <th class=""><label><?php echo e(__('Problems')); ?></label>
                        </th>
                        <th class=""><label><?php echo e(__('Solutions')); ?></label>

                        </th>
                        <th class=""><label><?php echo e(__('Unique Value Propositions')); ?></label>

                        </th>
                        <th class=""><label><?php echo e(__('Unfair Advantage')); ?></label>

                        </th>

                        <th scope="col"><label><?php echo e(__('Customer Segments')); ?></label>

                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="">
                            <?php echo clean($model->problems); ?>

                        </td>
                        <td>
                            <?php echo clean($model->solutions); ?></td>
                        <td>
                            <?php echo clean($model->value_propositions); ?>

                        </td>
                        <td>
                            <?php echo clean($model->unfair_advantage); ?>

                        </td>
                        <td><?php echo clean($model->customer_segments); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <label><?php echo e(__('Key Metrics')); ?></label>

                            <p><?php echo clean($model->key_matrices); ?></p>
                        </td>
                        <td></td>

                        <td>
                            <label><?php echo e(__('Channels')); ?></label>
                            <p><?php echo clean($model->channels); ?></p>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <label><?php echo e(__('Cost Structure')); ?></label>
                            <?php echo clean($model->cost_structure); ?>


                        </td>
                        <td colspan="3"><label><?php echo e(__('Revenue Stream')); ?></label>
                            <?php echo clean($model->revenue_stream); ?>


                        </td>
                    </tr>
                    <tr></tr>
                    <tr></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/startup-canvas/view-model.blade.php ENDPATH**/ ?>