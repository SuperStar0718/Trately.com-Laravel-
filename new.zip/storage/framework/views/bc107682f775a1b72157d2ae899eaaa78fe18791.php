










<?php if($form->has_first_name): ?>
<div class="mb-3">
    <label for="first_name">
        <?php if($form->label_first_name): ?>
            <?php echo e($form->label_first_name); ?>

        <?php else: ?>
        <?php echo e($fields['first_name']['default']['name']); ?>

        <?php endif; ?>
    </label>
    <input class="form-control" name="first_name" id="first_name">
</div>
<?php endif; ?>

<?php if($form->has_last_name): ?>
    <div class="mb-3">
        <label for="last_name">
            <?php if($form->label_last_name): ?>
                <?php echo e($form->label_last_name); ?>

            <?php else: ?>
                <?php echo e($fields['last_name']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="last_name" id="last_name">
    </div>
<?php endif; ?>
<?php if($form->has_email): ?>
    <div class="mb-3">
        <label for="email">
            <?php if($form->label_email): ?>
                <?php echo e($form->label_email); ?>

            <?php else: ?>
                <?php echo e($fields['email']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="email" id="email">
    </div>
<?php endif; ?>


<?php if($form->has_phone): ?>
    <div class="mb-3">
        <label for="phone">
            <?php if($form->label_phone): ?>
                <?php echo e($form->label_phone); ?>

            <?php else: ?>
                <?php echo e($fields['phone']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="phone" id="phone">
    </div>
<?php endif; ?>

<?php if($form->has_company): ?>
    <div class="mb-3">
        <label for="company">
            <?php if($form->label_company): ?>
                <?php echo e($form->label_company); ?>

            <?php else: ?>
                <?php echo e($fields['company']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="company" id="company">
    </div>
<?php endif; ?>

<?php if($form->has_employees): ?>
    <div class="mb-3">
        <label for="employees">
            <?php if($form->label_employees): ?>
                <?php echo e($form->label_employees); ?>

            <?php else: ?>
                <?php echo e($fields['employees']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="employees" id="employees">
    </div>
<?php endif; ?>


<?php if($form->has_website): ?>
    <div class="mb-3">
        <label for="website">
            <?php if($form->label_website): ?>
                <?php echo e($form->label_website); ?>

            <?php else: ?>
                <?php echo e($fields['website']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="website" id="website">
    </div>
<?php endif; ?>

<?php if($form->has_address_line_1): ?>
    <div class="mb-3">
        <label for="address_line_1">
            <?php if($form->label_address_line_1): ?>
                <?php echo e($form->label_address_line_1); ?>

            <?php else: ?>
                <?php echo e($fields['address_line_1']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="address_line_1" id="address_line_1">
    </div>
<?php endif; ?>

<?php if($form->has_address_line_2): ?>
    <div class="mb-3">
        <label for="address_line_2">
            <?php if($form->label_address_line_2): ?>
                <?php echo e($form->label_address_line_2); ?>

            <?php else: ?>
                <?php echo e($fields['address_line_2']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="address_line_2" id="address_line_2">
    </div>
<?php endif; ?>

<?php if($form->has_city): ?>
    <div class="mb-3">
        <label for="city">
            <?php if($form->label_city): ?>
                <?php echo e($form->label_city); ?>

            <?php else: ?>
                <?php echo e($fields['city']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="city" id="city">
    </div>
<?php endif; ?>

<?php if($form->has_state): ?>
    <div class="mb-3">
        <label for="state">
            <?php if($form->label_state): ?>
                <?php echo e($form->label_state); ?>

            <?php else: ?>
                <?php echo e($fields['state']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="state" id="state">
    </div>
<?php endif; ?>


<?php if($form->has_postal_code): ?>
    <div class="mb-3">
        <label for="postal_code">
            <?php if($form->label_postal_code): ?>
                <?php echo e($form->label_postal_code); ?>

            <?php else: ?>
                <?php echo e($fields['postal_code']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="postal_code" id="postal_code">
    </div>
<?php endif; ?>

<?php if($form->has_country): ?>
    <div class="mb-3">
        <label for="country">
            <?php if($form->label_country): ?>
                <?php echo e($form->label_country); ?>

            <?php else: ?>
                <?php echo e($fields['country']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="country" id="country">
    </div>
<?php endif; ?>


<?php if($form->has_notes): ?>
    <div class="mb-3">
        <label for="notes">
            <?php if($form->label_notes): ?>
                <?php echo e($form->label_notes); ?>

            <?php else: ?>
                <?php echo e($fields['notes']['default']['name']); ?>

            <?php endif; ?>
        </label>
        <input class="form-control" name="notes" id="notes">
    </div>
<?php endif; ?>



<?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/form-fields/generate-lead-capture-form.blade.php ENDPATH**/ ?>