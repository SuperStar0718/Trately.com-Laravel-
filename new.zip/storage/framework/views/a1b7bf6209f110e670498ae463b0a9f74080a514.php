<?php $__env->startSection('content'); ?>

    <h3>
        <?php echo e(__(' Checking File Permissions')); ?>


    </h3>

    <ul class="list-group mt-3">
        <li class="list-group-item border-0 ps-0 pt-0 text-sm">
            <strong class="text-dark">

                <?php echo e(__(' Env file (.env) write permission:')); ?>


            </strong>

            <?php if($write_permission_env): ?>
                <?php echo e(__(' Writable (Great!)')); ?>

            <?php else: ?>
                <?php echo e(__(' Unable to write .env file')); ?>

            <?php endif; ?>

        </li>
        <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong
                class="text-dark"><?php echo e(__('RouteServiceProvider.php:')); ?></strong>

            <?php if($write_permission_route_service_provider): ?>
                <?php echo e(__(' Writable (Great!)')); ?>

            <?php else: ?>
                <?php echo e(__('Unable to write RouteServiceProvider.php')); ?>


            <?php endif; ?>

        </li>
    </ul>

    <a class="btn btn-info mt-3" href="<?php echo e(route('step2')); ?>"><?php echo e(__('Continue')); ?></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/install/step1.blade.php ENDPATH**/ ?>