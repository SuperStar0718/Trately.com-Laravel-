<form action="/save-event" method="post" id="form_main">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <?php if($event): ?>
            <h4><?php echo e(__('Edit')); ?></h4>
        <?php else: ?>
            <h4><?php echo e(__('Add New Event')); ?></h4>
        <?php endif; ?>


    <div id="sp_result_div"></div>

    <div class="form-group">
        <label for="example-email-input" class="form-control-label"><?php echo e(__('Name')); ?></label>
        <input class="form-control" name="title" type="text"  id="name" value="<?php echo e($event->title ?? ''); ?>">
    </div>
    <div class="row mt-4">
        <div class="col-6">
            <label class="form-label"><?php echo e(__('Start Date & Time')); ?></label>
            <input class="form-control" name="start_date" type="datetime" id="start_date" value="<?php echo e($date); ?>">
        </div>
        <div class="col-6">
            <label class="form-label"><?php echo e(__('End Date & Time')); ?></label>
            <input class="form-control " name="end_date" type="datetime" id="end_date"



                   <?php if(!empty($event)): ?>
            value="<?php echo e($event->end_date); ?>"
                   <?php else: ?>
                   value="<?php echo e(date('Y-m-d')); ?>"
                <?php endif; ?>>
        </div>
    </div>
    <label class="mt-4 text-sm mb-0"><?php echo e(__('Event Description')); ?></label>
    <p class="form-text text-muted text-xs ms-1">
        <?php echo e(__('Write a description of the event')); ?>

    </p>

    <div class="form-group">

        <textarea class="form-control" rows="10" id="description" name="description"><?php if(!empty($event)): ?><?php echo $event->description; ?><?php endif; ?></textarea>
    </div>

    <?php echo csrf_field(); ?>
        <?php if($event): ?>
            <input type="hidden" name="id" value="<?php echo e($event->id); ?>">
        <?php endif; ?>
    <div class="text-right mt-4">

        <button type="submit" id="btn_submit" class="btn bg-gradient-primary">
            <?php echo e(__('Save')); ?>


        </button>

    </div>


</form>




<?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/plans/event.blade.php ENDPATH**/ ?>