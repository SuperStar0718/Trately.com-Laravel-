<?php $__env->startSection('content'); ?>

    <div class="page-header mb-4 border-radius-xl">
        <span class="mask bg-gradient-dark"></span>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 my-auto">

                    <h5 class="text-white fadeIn2 fadeInBottom mt-4">
                        <?php echo e(__('Turn Your Idea into Real Business.')); ?>


                    </h5>
                    <p class="text-white opacity-8 fadeIn3 fadeInBottom">
                        <?php echo e(__('Plan for your Dream Business ')); ?>


                    </p>
                </div>
            </div>
            <a  href="/write-business-plan" type="button" class="btn bg-gradient-light">
                <?php echo e(__('Write your Business Plan')); ?>


            </a>

        </div>
    </div>

    <div class="row">

        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card card-pricing ">
                    <div class="card-header bg-purple-light  text-center pt-4 pb-5 position-relative">
                        <div class="z-index-1 position-relative ">
                            <h5 class="mt-6"> <?php echo e($settings['company_name']); ?></h5>
                            <h3 class="text-purple mt-2 mb-2">
                                <?php echo e(__('Business Plan')); ?></h3>
                            <h6 class="text-muted">
                                <?php if(!empty($plan->date)): ?>
                                    <?php echo e($plan->date->format(config('app.date_format'))); ?>

                                <?php endif; ?></h6>
                        </div>
                    </div>
                    <div class="text-center mt-4">
                        <p class="text-muted"><?php echo e(__('Prepared by')); ?></p>
                        <h5><?php echo e($plan->name); ?></h5>
                        <h6 class="text-muted"><?php echo e($plan->email); ?></h6>

                    </div>

                    <div class="card-body text-center">

                        <a href="/view-business-plan?id=<?php echo e($plan->id); ?>" type="button" class="btn btn-success mb-3">
                            <?php echo e(__('Read')); ?>

                        </a>
                        <a class="btn btn-info mb-3" href="/write-business-plan?id=<?php echo e($plan->id); ?>"><?php echo e(__('Edit')); ?></a>
                        <a href="/delete/business-plan/<?php echo e($plan->id); ?>" type="button" class="btn btn-warning"><?php echo e(__('Delete')); ?></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/plans/business-plans.blade.php ENDPATH**/ ?>