<?php $__env->startSection('content'); ?>



    <div class="row ">
        <div class="col-lg-8 col-md-6 mb-md-0 ">
            <form action="/sms-settings" method="post">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card" id="sms_settings">
                    <div class="card-header">
                        <h6>SMS Settings</h6>
                    </div>
                    <div class="card-body pt-0">
                        <label class="form-label">SMS Providers</label>
                        <select name="provider" id="recaptcha" class="form-control">
                            <?php $__currentLoopData = $available_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <option value="<?php echo e($key); ?>">

                                <?php echo e($value); ?>


                            </option>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        </select>
                        <div class="mt-4">
                            <label class="form-label">SMS Provider Name</label>
                            <div class="form-group">
                                <input class="form-control"  id="recaptcha_sitekey" name="name" <?php if(!empty($sms_provider)): ?> value="<?php echo e($sms_provider->name); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="mt-4">
                            <label class="form-label">Sender ID</label>
                            <div class="form-group">
                                <input class="form-control"  id="recaptcha_sitekey" name="sender_id">
                            </div>
                        </div>

                        <label class="form-label">API Key</label>
                        <div class="form-group">
                            <input class="form-control"  id="recaptcha_sitekey" name="username" <?php if(!empty($sms_provider)): ?> value="<?php echo e($sms_provider->username); ?>" <?php endif; ?>>
                        </div>
                        <label class="form-label">API Secret Key</label>
                        <div class="form-group">
                            <input class="form-control" id="recaptcha_secretkey" name="password" <?php if(!empty($sms_provider)): ?> value="<?php echo e($sms_provider->password); ?>" <?php endif; ?>>
                        </div>

                        <?php if($sms_provider): ?>
                            <input type="hidden" name="id" value="<?php echo e($sms_provider->id); ?>">
                        <?php endif; ?>

                        <?php echo csrf_field(); ?>
                        <button class="btn bg-gradient-dark btn-sm float-left mt-4 mb-0">Update </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card h-100">
                <div class="card-header pb-0">
                    <h6>SMS Providers</h6>

                </div>
                <div class="card-body p-3">
                    <div class="timeline timeline-one-side">



                        <?php $__currentLoopData = $sms_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sms_provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="timeline-block">
                  <span class="timeline-step">
                    <i class="ni ni-money-coins text-dark text-gradient"></i>
                  </span>
                            <div class="timeline-content">
                                <h6 class="text-dark text-sm font-weight-bold mb-0"><?php echo e($sms_provider->name); ?></h6>
                                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo e($sms_provider->updated_at); ?></p>

                                <div class="ms-auto">
                                    <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/delete/sms-setting/<?php echo e($sms_provider->id); ?>"><i class="far fa-trash-alt me-2"></i>Delete</a>
                                    <a class="btn btn-link text-dark px-3 mb-0" href="/sms/providers?id=<?php echo e($sms_provider->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>
                                </div>

                            </div>

                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/sms/providers.blade.php ENDPATH**/ ?>