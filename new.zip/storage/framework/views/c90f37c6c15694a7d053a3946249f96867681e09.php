<?php $__env->startSection('content'); ?>


    <h3><?php echo e(__('Focus Installation')); ?></h3>
    <p>
        <?php echo e(__('We need the following information to install.')); ?>

    </p>

    <ul>
        <li><?php echo e(__('Database Name')); ?></li>
        <li><?php echo e(__('Database Username')); ?></li>
        <li><?php echo e(__('Database Password')); ?></li>
        <li><?php echo e(__('Database Host')); ?></li>
    </ul>

    <p><?php echo e(__('The system will also check the necessary file write permissions.')); ?></p>

    <a class="btn btn-primary mt-3" href="<?php echo e(route('step1')); ?>">
        <?php echo e(__('Continue')); ?>


    </a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/install/index.blade.php ENDPATH**/ ?>