<?php $__env->startSection('content'); ?>
    <div class="row d-print-none">


        <div class="col text-center">
            <h5 class="mb-2 text-secondary fw-bolder">
                <?php echo e(__('One Page Marketing plan of')); ?>

                <?php if(!empty($model)): ?>
                    <?php echo e($model->company_name); ?>

                <?php endif; ?>

            </h5>
        </div>

    </div>
    <div class="row mt-3">
        <div class="col-lg-1 col-md-1 pt-5 pt-lg-0 ms-lg-2 text-center d-print-none">


            <a href="/write-marketing-plan?id=<?php echo e($model->id); ?>" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Edit">
                <i class="fas fa-pen p-2"></i>
            </a>
            <a href="#" onclick="window.print()" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="Print">
                <i class="fas fa-print p-2"></i>
            </a>
            <a href="/marketing-plans" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="List">
                <i class="fas fa-ellipsis-h p-2"></i>
            </a>
        </div>
        <div class="col-sm-10">
            <div class="card">
                <div class="card-body">
                    <div class="card mb-3 shadow-none">
                        <div class="card-body bg-yellow-light">
                            <h6 class="text-dark fw-bolder"> <?php echo e(__('Business Summary')); ?></h6>
                            <p class="text-sm">
                                <?php if(!empty($model)): ?>
                                    <?php echo $model->summary; ?>

                                <?php endif; ?>
                            </p>


                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="card mb-3 shadow-none">
                                <div class="card-body bg-yellow-light">
                                    <h6 class="text-dark fw-bolder"><?php echo e(__('Company Description')); ?></h6>

                                    <p class="text-sm">
                                        <?php if(!empty($model)): ?>
                                            <?php echo $model->description; ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card mb-3 shadow-none">
                                <div class="card-body bg-yellow-light">
                                    <h6 class="text-dark fw-bolder"><?php echo e(__('Team')); ?></h6>

                                    <p class="text-sm">
                                        <?php if(!empty($model)): ?>
                                            <?php echo $model->team; ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col ">
                            <div class="card mb-3 shadow-none ">
                                <div class="card-body bg-yellow-light">
                                    <h6 class="text-dark fw-bolder"><?php echo e(__('Business Initiatives')); ?></h6>
                                    <p class="text-sm">
                                        <?php if(!empty($model)): ?>
                                            <?php echo $model->business_initiatives; ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card mb-3 shadow-none">
                                <div class="card-body bg-yellow-light">
                                    <h6 class="text-dark fw-bolder"><?php echo e(__('Target Market')); ?></h6>
                                    <p class="text-sm">
                                        <?php if(!empty($model)): ?>
                                            <?php echo $model->target_market; ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="card mb-3 shadow-none">
                                <div class="card-body bg-yellow-light">
                                    <h6 class="text-dark fw-bolder"><?php echo e(__('Budget')); ?></h6>
                                    <p class="text-sm">
                                        <?php if(!empty($model)): ?>
                                            <?php echo $model->budget; ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card mb-3 shadow-none">
                                <div class="card-body bg-yellow-light">
                                    <h6 class="text-dark fw-bolder"><?php echo e(__('Marketing Channels')); ?></h6>
                                    <p class="text-sm">
                                        <?php if(!empty($model)): ?>
                                            <?php echo $model->marketing_channels; ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/marketing/view.blade.php ENDPATH**/ ?>