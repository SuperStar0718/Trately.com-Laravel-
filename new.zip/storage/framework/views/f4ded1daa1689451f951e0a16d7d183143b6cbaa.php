<?php echo e(__('Follow this link to reset your password-')); ?> <?php echo e(config('app.url')); ?>/password-reset?id=<?php echo e($user->id); ?>&token=<?php echo e($user->password_reset_key); ?>

<?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/emails/password_reset.blade.php ENDPATH**/ ?>