<?php $__env->startSection('content'); ?>


    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="multisteps-form mb-5">
                    <!--progress bar-->

                    <!--form panels-->
                    <div class="row">
                        <div class="col-12 col-lg-8 m-auto">
                            <form action="/user-post"  method="post" class="multisteps-form__form mb-8">
                                <!--single form panel-->

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul class="list-unstyled">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="card multisteps-form__panel p-3 border-radius-xl bg-white js-active" data-animation="FadeIn">
                                    <h5 class="font-weight-bolder mb-0">
                                        <?php echo e(__('Add New User')); ?>


                                    </h5>

                                    <div class="multisteps-form__content">
                                        <div class="row mt-3">
                                            <div class="col-12 col-sm-6">
                                                <label><?php echo e(__('First Name')); ?></label>
                                                <input name="first_name"class="multisteps-form__input form-control" type="text" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->first_name); ?>" <?php endif; ?> />
                                            </div>
                                            <div class="col-12 col-sm-6 mt-3 mt-sm-0">
                                                <label><?php echo e(__('Last Name')); ?></label>
                                                <input name="last_name"class="multisteps-form__input form-control" type="text" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->last_name); ?>" <?php endif; ?> />
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-12">
                                                <label><?php echo e(__('Username/Email')); ?></label>
                                                <input name="email" class="multisteps-form__input form-control" type="email" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->email); ?>" <?php endif; ?>  />
                                            </div>

                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-12">
                                                <label><?php echo e(__('Password')); ?></label>

                                                <input name="password"  type="password" class="multisteps-form__input form-control" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->password); ?>" <?php endif; ?>/>
                                                <p class="text-xs">
                                                    <?php echo e(__('Keep blank if you do not want to change Password')); ?>

                                                    </p>

                                            </div>

                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-12 col-sm-6 mt-3 mt-sm-0">
                                                <label><?php echo e(__('Mobile Phone')); ?></label>
                                                <input name="mobile_number" class="multisteps-form__input form-control" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->mobile_number); ?>" <?php endif; ?> >
                                            </div>
                                            <div class="col-12 col-sm-6 mt-3 mt-sm-0">
                                                <label><?php echo e(__('Telephone')); ?></label>
                                                <input name="phone_number"class="multisteps-form__input form-control"  <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->phone_number); ?>" <?php endif; ?>  />
                                            </div>


                                        </div>


                                    </div>
                                </div>



                                <div class="card mt-4 multisteps-form__panel p-3 border-radius-xl bg-white" data-animation="FadeIn">
                                    <h5 class="font-weight-bolder"><?php echo e(__('Socials')); ?></h5>
                                    <div class="multisteps-form__content">
                                        <div class="row mt-3">
                                            <div class="col-12">
                                                <label><?php echo e(__('Twitter Handle')); ?></label>
                                                <input  name="twitter" class="multisteps-form__input form-control" type="text" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->twitter); ?>" <?php endif; ?> />
                                            </div>
                                            <div class="col-12 mt-3">
                                                <label><?php echo e(__('Facebook Account')); ?></label>
                                                <input name="facebook" class="multisteps-form__input form-control" type="text" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->facebook); ?>" <?php endif; ?> />
                                            </div>
                                            <div class="col-12 mt-3">
                                                <label><?php echo e(__('Linkedin Account')); ?></label>
                                                <input name="linkedin" class="multisteps-form__input form-control" <?php if(!empty($selected_user)): ?> value="<?php echo e($selected_user->linkedin); ?>" <?php endif; ?> />
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <!--single form panel-->
                                <?php echo csrf_field(); ?>

                                <?php if(!empty($selected_user)): ?>
                                    <input type="hidden" name="id" value="<?php echo e($selected_user->id); ?>">
                                <?php endif; ?>
                                <div class="button-row text-left mt-4">
                                    <button class="btn bg-gradient-dark ms-auto mb-0 js-btn-next" type="submit" title="Next"><?php echo e(__('Submit')); ?></button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/profile/new-user.blade.php ENDPATH**/ ?>