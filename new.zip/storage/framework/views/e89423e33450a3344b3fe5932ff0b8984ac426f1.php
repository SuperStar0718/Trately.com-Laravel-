<?php $__env->startSection('content'); ?>


    <form method="post" action="/contact">
    <div class="card multisteps-form__panel p-3 border-radius-xl bg-white js-active  mb-3 mt-4">
        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">
                    <h6 class="mb-0">Add New Contact</h6>
                </div>
                <div class="col-md-6 text-right">

                    <a class="btn bg-gradient-secondary mb-0" href="/people">&nbsp;&nbsp;Go to Contact List</a>
                </div>
            </div>
        </div>
        <div class="card-body  p-3">


                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <div class="form-group">
                    <label for="example-tel-input" class="form-control-label">Audience</label>
                    <select class="form-select" aria-label="Default select example" name="audience_id" >
                        <option>None</option>
                        <?php $__currentLoopData = $audiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($audience->id); ?>"
                                <?php if(!empty($contact)): ?>
                                <?php if($contact->audience_id == $audience->id): ?>
                            selected
                            <?php endif; ?>
                            <?php endif; ?>
                            ><?php echo e($audience->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-text-input" class="form-control-label">First Name</label>
                            <input class="form-control" name="first_name" type="text"  <?php if(!empty($contact)): ?> value="<?php echo e($contact->first_name); ?>" <?php endif; ?> id="example-text-input">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-text-input" class="form-control-label">Last Name</label>
                            <input class="form-control" name="last_name"type="text" <?php if(!empty($contact)): ?> value="<?php echo e($contact->last_name); ?>" <?php endif; ?> id="example-text-input">
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label for="example-email-input" class="form-control-label">Email</label>
                    <input class="form-control" name="email" type="email" <?php if(!empty($contact)): ?> value="<?php echo e($contact->email); ?>" <?php endif; ?> id="example-email-input">
                </div>

                <div class="form-group">
                    <label for="example-tel-input" class="form-control-label">Phone</label>
                    <input class="form-control" name="phone_number" type="tel" <?php if(!empty($contact)): ?> value="<?php echo e($contact->phone_number); ?>" <?php endif; ?> id="example-tel-input">
                </div>

                    <div class="multisteps-form__content">
                        <div class="row mt-3">
                            <div class="col">
                                <label>Address Line 1</label>
                                <input class="multisteps-form__input form-control" type="text" name="address_line_1" <?php if(!empty($contact)): ?> value="<?php echo e($contact->address_line_1); ?>" <?php endif; ?> />
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <label>Address Line 2</label>
                                <input class="multisteps-form__input form-control" type="text" name="address_line_2" <?php if(!empty($contact)): ?> value="<?php echo e($contact->address_line_2); ?>" <?php endif; ?> />
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label>City</label>
                                    <input class="multisteps-form__input form-control" type="text" name="city" <?php if(!empty($contact)): ?> value="<?php echo e($contact->city); ?>" <?php endif; ?>  />
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label>State</label>
                                    <input class="multisteps-form__input form-control" type="text" name="state" <?php if(!empty($contact)): ?> value="<?php echo e($contact->state); ?>" <?php endif; ?>  />
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label>Zip</label>
                                    <input class="multisteps-form__input form-control" type="text" name="zip" <?php if(!empty($contact)): ?> value="<?php echo e($contact->zip); ?>" <?php endif; ?>  />
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label>Country</label>
                                    <select class="form-select" name="country">
                                        <option value="">--</option>

                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country['name']); ?>

                                            <?php if(!empty($contact)): ?>
                                            <?php if($contact->country): ?>
                                                selected
<?php endif; ?>
                                            <?php endif; ?>
                                                ><?php echo e($country['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>
                        </div>

                    </div>
                    <?php echo csrf_field(); ?>

                    <?php if(!empty($contact)): ?>
                        <input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
                    <?php endif; ?>
                    <div class="mt-4">
                        <button type="Submit" class="btn btn-secondary">Save</button>
                        <button type="button" class="btn btn-primary">close</button>

                    </div>


        </div>
    </div>







    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/contacts/contact.blade.php ENDPATH**/ ?>