<?php $__env->startSection('content'); ?>


    <h3>
        <?php echo e(__('StartupKit Installation')); ?>


    </h3>
    <p>
        <?php echo e(__('Database connection was successful! On the next step, system will import the primary data.')); ?>


    </p>

    <p>
        <?php echo e(__('While importing the database, it might take some time depending on your system. Click Continue Once!')); ?>

    </p>


    <a class="btn btn-info mt-3" href="<?php echo e(route('import.sql')); ?>">
        <?php echo e(__('Continue')); ?>


    </a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/install/step3.blade.php ENDPATH**/ ?>