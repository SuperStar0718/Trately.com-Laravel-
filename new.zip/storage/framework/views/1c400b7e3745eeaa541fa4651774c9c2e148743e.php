<?php $__env->startSection('title',$blog->title); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <h5 class=" col fw-bolder">
            <?php echo e($blog->topic); ?>

        </h5>
        <div class="col text-end mb-3">
            <a href="/write-blog?id=<?php echo e($blog->id); ?>" class="btn btn-info btn-sm mb-0"><?php echo e(__('Edit')); ?></a>
            <a href="/delete/blog/<?php echo e($blog->id); ?>" class="btn btn-warning btn-sm mb-0"><?php echo e(__('Delete')); ?></a>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card-header p-0 mx-3 mt-3 position-relative z-index-1">
                        <a href="javascript:" class="d-block">
                            <?php if(!empty($blog->cover_photo)): ?>
                                <img src="<?php echo e(PUBLIC_DIR); ?>/uploads/<?php echo e($blog->cover_photo); ?>" class="img-fluid border-radius-lg">

                            <?php endif; ?>

                        </a>
                    </div>

                </div>
            </div>

        </div>

        <div class="card-body col-md-8 mx-auto pt-2">
            <h2 class="mt-3"><?php echo e($blog->title); ?></h2>
            <a href="/profile" class="nav-link text-body font-weight-bold px-0">
                        <span class="d-sm-inline d-none "> <?php if(isset($users[$blog->admin_id])): ?>
                                <?php echo e($users[$blog->admin_id]->first_name); ?>  <?php echo e($users[$blog->admin_id]->last_name); ?>

                            <?php endif; ?>
                        </span>
            </a>
            <p class="">
                <?php echo e((\App\Supports\DateSupport::parse($blog->created_at))->format(config('app.date_format'))); ?>


            </p>

            <div class="mb-4">
                <?php echo clean($blog->notes); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super-admin-portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/blog/view-blog.blade.php ENDPATH**/ ?>