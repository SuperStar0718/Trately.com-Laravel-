<?php $__env->startSection('content'); ?>

    <div class="row  mb-5">


        <div class="col-md-4 ">
            <div class="card bg-info mb-4 ">
                <div class="card-body">
                    <h5 class="fw-bolder text-white mb-4"><?php echo e(__('Investment Details')); ?></h5>
                    <h6 class="text-white">
                        Product: <?php if(!empty($products[$investor->product_id])): ?>
                            <?php if(isset($products[$investor->product_id])): ?>
                                <?php echo e($products[$investor->product_id]->title); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </h6>
                    <h6 class="text-white">

    <?php echo e(__(' Amount:')); ?> <?php echo e(formatCurrency($investor->amount,getWorkspaceCurrency($super_settings))); ?>

  </h6>


      <h6 class="text-white"><span><?php echo e(__('Status:')); ?></span><span class="text-success">

       <?php echo e($investor->status); ?>




                    </span> </h6>



</div>
</div>
<div class="card">

<div class="card-body">

  <h5 class="fw-bolder mb-4"><?php echo e(__('Investor Information')); ?></h5>

  <ul class="flex-row  nav ">
      <?php if(!empty($investor->facebook)): ?>
          <li class="nav-item ">
              <a class="nav-link " href="<?php echo e($investor->facebook); ?>" target="_blank">
                  <button type="button" class="btn rounded-circle bg-info-alt btn-facebook btn-icon-only">
                      <span class="btn-inner--icon"><i class="fab fa-facebook"></i></span>
                  </button>
              </a>
          </li>

      <?php endif; ?>

      <?php if(!empty($investor->linkedin)): ?>
          <li class="nav-item">
              <a class="nav-link " href="<?php echo e($investor->linkedin); ?>" target="_blank">
                  <button type="button" class="btn rounded-circle bg-info btn-linkedin btn-icon-only">
                      <span class="btn-inner--icon"><i class="fab fa-linkedin text-white"></i></span>
                  </button>
              </a>
          </li>

      <?php endif; ?>

      <?php if(!empty($investor->twitter)): ?>
          <li class="nav-item">
              <a class="nav-link " href="<?php echo e($investor->twitter); ?>" target="_blank">
                  <button type="button" class="btn rounded-circle btn-twitter btn-icon-only">
                      <span class="btn-inner--icon"><i class="fab fa-twitter"></i></span>
                  </button>
              </a>
          </li>
      <?php endif; ?>
  </ul>

  <ul class="list-group">
      <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong
              class="text-dark"><?php echo e(__('Full Name:')); ?></strong>
          <?php echo e($investor->first_name); ?> <?php echo e($investor->last_name); ?>

      </li>
      <li class="list-group-item border-0 ps-0 text-sm"><strong
              class="text-dark"><?php echo e(__('Phone Number:')); ?></strong>
          <?php echo e($investor->phone_number); ?>

      </li>
      <li class="list-group-item border-0 ps-0 text-sm"><strong
              class="text-dark"><?php echo e(__('Email:')); ?></strong> <?php echo e($investor->email); ?></li>
      <li class="list-group-item border-0 ps-0 text-sm"><strong
              class="text-dark"><?php echo e(__('Account Created:')); ?></strong> <?php echo e((\App\Supports\DateSupport::parse($investor->created_at))->format(config('app.date_time_format'))); ?>

      </li>
      <li class="list-group-item border-0 ps-0 text-sm"><strong
              class="text-dark"><?php echo e(__('Source:')); ?></strong> <?php echo e($investor->source); ?></li>


  </ul>
  <a class="btn btn-info btn-sm mb-0 mt-3" href="/add-investor?id=<?php echo e($investor->id); ?>"><?php echo e(__('Edit')); ?></a>

</div>
</div>
</div>

<div class="col-md-8 mt-lg-0 mt-4">

<div class="card">
<div class="card-body">
<h5 class="fw-bolder mb-4"><?php echo e(__('Notes')); ?></h5>
<?php echo $investor->notes; ?>

</div>
</div>

</div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/investors/view.blade.php ENDPATH**/ ?>