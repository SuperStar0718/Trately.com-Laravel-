<?php $__env->startSection('content'); ?>

    <div class=" row">
        <div class="col">
            <h5 class=" text-secondary fw-bolder">
                <?php echo e(__('Sticky Notes')); ?>

            </h5>

        </div>

        <div class="col text-end">
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal">
               <?php echo e(__(' New Note')); ?>

            </button>

        </div>

    </div>


    <!-- Button trigger modal -->



    <div class="row " data-masonry='{"percentPosition": true }'>
        <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2 mb-4">

                <div class="card card-frame">
                    <div class="card-body">
                       <?php echo e($note->notes); ?>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>






    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">

            <div class="modal-content">

                <form method="post" action="/save-sticky-note" id="form_main">

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Sticky Note')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Note')); ?></label>
                            <textarea class="form-control" name="notes" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>


                </div>

                <div class="text-end me-3">
                    <button type="button" class="btn btn-sm bg-gradient-secondary" data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>

                    <?php echo csrf_field(); ?>
                    <button type="submit"  id="btn_submit" class="btn btn-sm btn-info"><?php echo e(__('Save')); ?></button>
                </div>
                </form>

            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/sticky-note/notes.blade.php ENDPATH**/ ?>