<?php $__env->startSection('content'); ?>


    <div class="card mb-3 mt-4">
        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">
                    <div class="col-md-6 text-left">
                        <a class="btn bg-gradient-dark mb-2" href="/people">&nbsp;&nbsp;people</a>
                        <a class="btn bg-gradient-dark mb-2" href="/audiences">&nbsp;&nbsp;Audiences</a>
                    </div>

                </div>
                <div class="col-md-6 text-right">
                    <a class="btn bg-gradient-primary mb-0" href="/new-contact"><i class="fas fa-upload"></i>&nbsp;&nbsp;Import Contacts</a>
                    <a class="btn bg-gradient-dark mb-0" href="/new-contact"><i class="fas fa-plus"></i>&nbsp;&nbsp;Add New Contact</a>
                </div>
            </div>
        </div>
        <div class="card-body  p-3">

        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card mb-4">


                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Email</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Phone</th>

                                <th class="text-secondary opacity-7"></th>
                            </tr>


                            <tbody>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td>
                                        <div class="d-flex px-2 py-1">

                                            <div class="d-flex flex-column justify-content-center">
                                                <h6 class="mb-0 text-sm"><?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></h6>

                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($contact->email); ?></p>

                                    </td>

                                    <td class="align-middle text-center">
                                        <span class="text-secondary text-xs font-weight-bold"><?php echo e($contact->phone_number); ?></span>
                                    </td>
                                    <td class="align-middle text-right">
                                        <div class="ms-auto">
                                            <a class="btn btn-link text-dark px-3 mb-0" href="/contact-view/<?php echo e($contact->id); ?>"><i class="fas fa-file text-dark me-2" aria-hidden="true"></i>View</a>
                                            <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/delete/contact/<?php echo e($contact->id); ?>"><i class="far fa-trash-alt me-2"></i>Delete</a>
                                            <a class="btn btn-link text-dark px-3 mb-0" href="/contact-edit/<?php echo e($contact->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>
                                        </div>




                                    </td>
                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/contacts/people.blade.php ENDPATH**/ ?>