<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-5">

       <div class="card">
           <div class="card-header">
<h6>Form</h6>
           </div>
           <div class="card-body">

               <a href="/lead-capture-form?id=<?php echo e($form->id); ?>" type="button" class="btn bg-gradient-secondary">Edit</a>
               <a href="/form/<?php echo e($form->uuid); ?>" target="_blank" type="button" class="btn bg-gradient-dark">Share</a>
               <a href="/delete/lead-capture-form/<?php echo e($form->id); ?>" type="button" class="btn bg-gradient-primary">DELETE</a>



               <div class="mb-3">
                   <h6 class="mb-3">Link</h6>

                   <input class="form-control" value="<?php echo e(config('app.url')); ?>/form/<?php echo e($form->uuid); ?>" onClick="this.setSelectionRange(0, this.value.length)">
               </div>

               <h6 class="mb-3">Embed</h6>
               <div class="mb-3">
                   <code><?php echo e($embed_code); ?></code>
               </div>



           </div>


       </div>

    </div>

    <div class="col-md-7">

        <div class="card">
            <div class="card-header">
                <h6>Form</h6>
            </div>
            <div class="card-body">
                <div class="hr-line-dashed"></div>

                <?php echo $__env->make('form-fields/generate-lead-capture-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>
        </div>

    </div>





</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/contacts/manage-lead-form.blade.php ENDPATH**/ ?>