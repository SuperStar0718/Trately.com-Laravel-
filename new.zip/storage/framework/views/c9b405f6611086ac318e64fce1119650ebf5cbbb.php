<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="mb-5">
                <div class="row">
                    <div class="col-12 col-lg-8 m-auto">
                        <form action="/save-workspace" method="post" class="multisteps-form__form mb-8">
                            <!--single form panel-->

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul class="list-unstyled">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div>
                                <h5 class="font-weight-bolder mb-0">
                                    <?php echo e(__('Edit Workspace')); ?>

                                </h5>
                                <div class="multisteps-form__content">
                                    <div class="row mt-3">
                                        <div class="col-12 col-sm-6">
                                            <label><?php echo e(__('Workspace Name')); ?></label>
                                            <input name="name" class="multisteps-form__input form-control" type="text"
                                                   <?php if(!empty($workspace)): ?> value="<?php echo e($workspace->name); ?>" <?php endif; ?> />
                                        </div>
                                        <?php if($workspace->id !== $user->workspace_id): ?>
                                            <div class="form-group">
                                                <label for="example-text-input" class="form-control-label">
                                                    <?php echo e(__('Choose a plan ')); ?>


                                                </label><span class="text-danger">*</span>

                                                <select class="form-select" aria-label="Default select example" name="plan_id">   <option value="0"><?php echo e(__('None')); ?></option><?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($plan->id); ?>"
                                                                <?php if(!empty($workspace)): ?>
                                                                <?php if($workspace->plan_id == $plan->id): ?>
                                                                selected
                                                            <?php endif; ?>
                                                            <?php endif; ?>
                                                        ><?php echo e($plan->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label><?php echo e(__('Next Renewal Date')); ?></label>
                                                <input class="form-control" type="date" name="next_renewal_date" value="<?php echo e($workspace->next_renewal_date ?? ''); ?>">
                                            </div>

                                        <?php endif; ?>

                                    </div>

                                </div>
                            </div>


                            <!--single form panel-->
                            <?php echo csrf_field(); ?>

                            <?php if(!empty($workspace)): ?>
                                <input type="hidden" name="id" value="<?php echo e($workspace->id); ?>">
                            <?php endif; ?>
                            <div class="button-row  mt-4">
                                <button class="btn btn-info ms-auto mb-0 js-btn-next" type="submit"><?php echo e(__('Submit')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.super-admin-portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/super-admin/edit-workspaces.blade.php ENDPATH**/ ?>