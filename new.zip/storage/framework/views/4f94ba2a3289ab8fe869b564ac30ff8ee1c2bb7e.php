<?php $__env->startComponent('mail::message'); ?>
# <?php echo e(__('Welcome')); ?> <?php echo e($user->first_name); ?>!

<?php echo e(__('Thanks For Signing Up. We’re thrilled to see you here!')); ?>


<?php $__env->startComponent('mail::button', ['url' => config('app.url')]); ?>
        <?php echo e(__('Login')); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo e(__('Thanks')); ?>,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/emails/welcome.blade.php ENDPATH**/ ?>