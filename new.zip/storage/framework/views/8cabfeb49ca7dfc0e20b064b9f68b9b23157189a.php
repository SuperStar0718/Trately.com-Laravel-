<div id="tasks_calendar_view"></div>
<?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/tasks/tabs/calendar_view.blade.php ENDPATH**/ ?>