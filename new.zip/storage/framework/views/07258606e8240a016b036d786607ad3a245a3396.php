<?php $__env->startSection('content'); ?>




    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header p-3">
                        <h5 class="mb-2">Diary Collection</h5>
                        <p class="mb-0">Track and find all the details about our referral program, your stats and revenues.</p>
                        <a  href="/weekly-plans" type="button" class="btn bg-gradient-dark mt-4">Design the Cover of your diary</a>

                    </div>

                    <div class="card-body p-3">


                        <hr class="horizontal dark">
                        <div class="row mt-4">
                            <h6 class="mb-2">My diaries</h6>


                            <div class="col-lg-4 col-md-6 col-12 mt-4 mt-lg-0">
                                <div class="card text-center">
                                    <div class="overflow-hidden position-relative border-radius-lg bg-cover p-3" style="background-color: #0b5d6f">
                                        <span class=" bg-gradient-dark opacity-6"></span>
                                        <div class="card-body position-relative z-index-1 d-flex flex-column mt-5">
                                            <h1 class="text-white font-weight-bolder">Study</h1>
                                            <h3 class="text-white font-weight-bolder">Diary</h3>
                                            <a class="text-white text-sm font-weight-bold mb-0 icon-move-right mt-4" href="javascript:;">
                                                Read More
                                                <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/gratitude/diary.blade.php ENDPATH**/ ?>