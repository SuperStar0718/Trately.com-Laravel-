<?php echo e($slot); ?>

<?php /**PATH /home4/asbwo9e2/trately.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>