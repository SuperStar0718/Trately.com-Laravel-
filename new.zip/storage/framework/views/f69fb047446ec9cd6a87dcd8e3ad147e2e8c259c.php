<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="card">
        <div class="card-header">

            <span class="float-end">
                 <a  href="/gratitude" type="button" class="btn bg-gradient-dark mt-4"><?php echo e(__('Go back to list')); ?></a>
            </span>
            <h4> <?php echo e(__('Journal of  - ')); ?><?php echo e($journal->date); ?></h4>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">
                        <h5><?php echo e(__('2 things I am grateful for')); ?></h5>



                    </li>
                    <p> <?php echo clean($journal->grateful); ?></p>

                </div>
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">    <h5><?php echo e(__('What would make me feel great today')); ?></h5>


                    </li>
                    <p> <?php echo clean($journal->feeling); ?></p>


                </div>


            </div>
            <div class="row">
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">     <h5><?php echo e(__('Daily affirmations')); ?></h5>


                    </li>
                    <p> <?php echo clean($journal->affirmations); ?></p>

                </div>
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">       <h5><?php echo e(__('Favorite things of my day')); ?></h5>



                    </li>
                    <p> <?php echo clean($journal->fav_things); ?></p>


                </div>


            </div>
            <div class="row">
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">    <h5>
                            <?php echo e(__('What can i do today that will bring me closer to my dream')); ?>

                        </h5>

                    </li>
                    <p><?php echo clean($journal->dream); ?></p>

                </div>
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">   <h5><?php echo e(__('What positive habit i have developed')); ?></h5>

                    </li>
                    <p> <?php echo clean($journal->habit); ?></p>


                </div>


            </div>
            <div class="row">
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">    <h5><?php echo e(__('I should not waste time on')); ?></h5>

                    </li>
                    <p> <?php echo clean($journal->dont_waste); ?></p>

                </div>
                <div class="col-md-6">

                    <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">   <h5><?php echo e(__('What are the things i must accomplish today (Non-Negotiable)')); ?></h5>


                    </li>
                    <p> <?php echo clean($journal->must_accomplish); ?></p>


                </div>


            </div>



        </div>
    </div>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/gratitude/view-journal.blade.php ENDPATH**/ ?>