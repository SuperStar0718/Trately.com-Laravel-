<?php $__env->startSection('content'); ?>
    <div class=" row mt-1 d-print-none">
        <div class="col">
            <h5 class="text-secondary fw-bolder">
                <?php echo e(__('Business Model Canvas of')); ?> <?php echo e($model->company_name); ?>

            </h5>
        </div>
        <div class="col text-end">
            
            <a href="#" onclick="window.print()"
               class="btn bg-gradient-dark btn-sm add_event waves-effect waves-light"><?php echo e(__('Print')); ?></a>
            <a href="/design-business-model?id=<?php echo e($model->id); ?>"
               class="btn btn-sm btn-warning add_event waves-effect waves-light"><?php echo e(__('Edit')); ?></a>
            <a href="/delete/business-model/<?php echo e($model->id); ?>"
               class="btn btn-sm btn-danger add_event waves-effect waves-light"><?php echo e(__('Delete')); ?></a>
        </div>
    </div>
    <div class="">
        <div class="">

            <div class="table-responsive bg-purple-light">
                <table class="table align-items-center mb-0 table-bordered">
                    <thead>
                    <tr>
                        <th class=""><label><?php echo e(__('Key partners')); ?></label>
                        </th>
                        <th class=""><label><?php echo e(__('Key activities')); ?></label>

                        </th>
                        <th class=""><label><?php echo e(__('Value Propositions')); ?></label>

                        </th>
                        <th class=""><label><?php echo e(__('Customer Relationships')); ?></label>

                        </th>

                        <th scope="col"><label><?php echo e(__('Customer Segments')); ?></label>

                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="">
                            <?php echo clean($model->partners); ?>

                        </td>
                        <td>
                            <?php echo clean($model->activities); ?></td>
                        <td>
                            <?php echo clean($model->value_propositions); ?>

                        </td>
                        <td>
                            <?php echo clean($model->customer_relationships); ?>

                        </td>
                        <td><?php echo clean($model->customer_segments); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <label><?php echo e(__('Key Resources')); ?></label>

                            <p><?php echo clean($model->resources); ?></p>
                        </td>
                        <td></td>

                        <td>
                            <label><?php echo e(__('Channels')); ?></label>
                            <p><?php echo clean($model->channels); ?></p>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <label><?php echo e(__('Cost Structure')); ?></label>
                            <?php echo clean($model->cost_structure); ?>


                        </td>
                        <td colspan="3"><label><?php echo e(__('Revenue Stream')); ?></label>
                            <?php echo clean($model->revenue_stream); ?>


                        </td>
                    </tr>
                    <tr></tr>
                    <tr></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/asbwo9e2/trately.com/resources/views/business-model/view-model.blade.php ENDPATH**/ ?>