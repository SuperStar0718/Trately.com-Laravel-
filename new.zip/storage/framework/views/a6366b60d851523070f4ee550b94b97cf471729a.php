<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <?php echo e(__('Plan Your Week')); ?>


        </div>



        <div class="card-body">
            <form action="/save-weeklyplan" method="post">
                <div class="form-group">
                    <label for="example-text-input" class="form-control-label"><?php echo e(__('Title')); ?> </label><span class="text-danger">*</span>
                    <input class="form-control" type="text" name="title" id="example-text-input"
                           <?php if(!empty($plan)): ?> value="<?php echo e($plan->title); ?>" <?php endif; ?>>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-date-input" class="form-control-label">
                                <?php echo e(__('From Date')); ?>


                            </label>
                            <input class="form-control"  name="from_date"   id="fromdate"
                                   <?php if(!empty($plan)): ?>
                                   value="<?php echo e($plan->from_date); ?>"
                                   <?php else: ?>
                                   value="<?php echo e(date('Y-m-d')); ?>"
                                <?php endif; ?>>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="example-date-input" class="form-control-label">
                               <?php echo e(__('To Date')); ?>


                            </label>
                            <input class="form-control" name="to_date" id="todate"
                                   <?php if(!empty($plan)): ?>
                                   value="<?php echo e($plan->to_date); ?>"
                                   <?php else: ?>
                                   value="<?php echo e(date('Y-m-d')); ?>"
                                <?php endif; ?>>
                        </div>

                    </div>
                </div>




                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">
                                <?php echo e(__('Monday')); ?>


                            </label>
                            <textarea class="form-control" name="monday" id="monday" rows="10"><?php if(!empty($plan)): ?> <?php echo e($plan->monday); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Tuesday')); ?></label>
                            <textarea class="form-control" name="tuesday" id="tuesday" rows="10">
                                <?php if(!empty($plan)): ?><?php echo e($plan->tuesday); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Wednesday')); ?></label>
                            <textarea class="form-control" name="wednesday" id="wednesday" rows="10">
                                <?php if(!empty($plan)): ?><?php echo e($plan->wednesday); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Thursday')); ?></label>
                            <textarea class="form-control" name="thursday" id="thursday" rows="10">
                                <?php if(!empty($plan)): ?><?php echo e($plan->thursday); ?><?php endif; ?>
                            </textarea>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Friday')); ?></label>
                            <textarea class="form-control" name="friday" id="friday" rows="10">
                                <?php if(!empty($plan)): ?><?php echo e($plan->friday); ?><?php endif; ?>
                            </textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Saturday')); ?></label>
                            <textarea class="form-control" name="saturday" id="saturday" rows="10">
                                <?php if(!empty($plan)): ?><?php echo e($plan->saturday); ?><?php endif; ?>
                            </textarea>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Sunday')); ?></label>
                            <textarea class="form-control" name="sunday" id="sunday" rows="10">
                                <?php if(!empty($plan)): ?><?php echo e($plan->sunday); ?><?php endif; ?>
                            </textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"><?php echo e(__('Notes')); ?></label>
                            <textarea class="form-control" name="notes" id="notes" rows="10"></textarea>
                        </div>

                    </div>
                </div>


                <?php if($plan): ?>
                    <input type="hidden" name="id" value="<?php echo e($plan->id); ?>">
                <?php endif; ?>

                <?php echo csrf_field(); ?>
                <button type="submit" class="btn bg-gradient-secondary"><?php echo e(__('Save')); ?></button>
                <button type="button" class="btn bg-gradient-secondary"><?php echo e(__('Close')); ?></button>
            </form>


        </div>


    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script>
        "use strict";
        $(function () {


            flatpickr("#fromdate", {

                dateFormat: "Y-m-d",
            });
            flatpickr("#todate", {

                dateFormat: "Y-m-d",
            });



        });


    </script>
    <script>

        tinymce.init({
            selector: '#grateful',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#saturday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#sunday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#monday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#tuesday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#wednesday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#thursday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#friday',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#notes',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
    </script>

<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/plans/weekly-plan.blade.php ENDPATH**/ ?>