<?php $__env->startSection('content'); ?>




    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-2">
                            <?php echo e(__('My Daily Journals')); ?>

                        </h6>
                        <span>
</span>
                        <p class="mb-0 text-sm">
                            <?php echo e(__('Free your mind from the noise of thousands of thoughts and set your intention for the day. This practice has proven to be the most effective in terms of productivity and mental peace.')); ?>

                        </p>
                        <a  href="/add-five-min-journal" type="button" class="btn bg-gradient-dark mt-4"><?php echo e(__('New Five Minute Journal')); ?></a>

                    </div>

                    <div class="card-body ">

                        <div class="row">



                            <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 col-12 mt-4 mt-lg-0 mb-4">
                                    <div class="card text-center">
                                        <div class="overflow-hidden bg-gradient-secondary  position-relative border-radius-lg bg-cover p-3">
                                            <span class=" bg-gradient-light opacity-6"></span>
                                            <div class="card-body position-relative z-index-1 d-flex flex-column mt-5">
                                                <h4 class="text-white"><?php echo e(__('5 Minute Journal')); ?></h4>
                                                <h4 class="text-white"><?php echo e($journal->date); ?></h4>
                                                <a class="text-white text-sm font-weight-bold mb-0 icon-move-right mt-4" href="/view-journal?id=<?php echo e($journal->id); ?>">
                                                    <?php echo e(__('Read More')); ?>

                                                    <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
                                                </a>
                                                <div class="mt-4">
                                                    <a href="/add-five-min-journal?id=<?php echo e($journal->id); ?>" type="button" class="btn btn-outline-light">
                                                        <?php echo e(__('Edit')); ?>


                                                    </a>
                                                    <a href="/delete/journal/<?php echo e($journal->id); ?>" type="button" class="btn btn-light"><?php echo e(__('Delete')); ?></a>

                                                </div>




                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/gratitude/gratitude.blade.php ENDPATH**/ ?>