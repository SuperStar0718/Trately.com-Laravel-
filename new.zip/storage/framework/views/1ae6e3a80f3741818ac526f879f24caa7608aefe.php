<?php $__env->startSection('content'); ?>

    <div class="">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header mx-4 p-3 text-center ">
                                    <div class="icon icon-shape icon-lg bg-gradient-dark shadow text-center border-radius-lg">
                                        <i class="fas fa-coins opacity-10"></i>
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0"><?php echo e(__('Plans')); ?></h6>
                                    <span class="text-xs"><?php echo e(__('Total Plans')); ?></span>
                                    <hr class="horizontal dark my-3">
                                    <h5 class="mb-0"><?php echo e($total_plans); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header mx-4 p-3 text-center">
                                    <div class="icon icon-shape icon-lg bg-gradient-success shadow text-center border-radius-lg">
                                        <i class="fas fa-user opacity-10"></i>
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0"><?php echo e(__('Users')); ?></h6>
                                    <span class="text-xs"><?php echo e(__('Total Userss')); ?></span>
                                    <hr class="horizontal dark my-3">
                                    <h5 class="mb-0"><?php echo e($total_users); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mt-md-0 mt-4">
                            <div class="card">
                                <div class="card-header mx-4 p-3 text-center">
                                    <div class="icon icon-shape icon-lg bg-gradient-info shadow text-center border-radius-lg">
                                        <i class="fas fa-pen opacity-10"></i>
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0"><?php echo e(__('Workspaces')); ?></h6>
                                    <span class="text-xs"><?php echo e(__('Total Workspaces')); ?></span>
                                    <hr class="horizontal dark my-3">
                                    <h5 class="mb-0"><?php echo e($total_workspaces); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 mb-lg-0 mb-3">
                        <div class="card  mt-4">
                            <div class="card-header pb-0 p-3">
                                <div class="row">
                                    <div class="col-6 d-flex align-items-center">
                                        <h6 class="mb-0"><?php echo e(__('Payment Method')); ?></h6>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table align-items-center mb-0">

                                            <tbody>

                                            <tr>
                                                <td>
                                                    <div class="d-flex px-2">
                                                        <div>
                                                            <img alt="Stripe" src="<?php echo e(PUBLIC_DIR); ?>/img/stripe.svg">
                                                        </div>

                                                    </div>
                                                </td>

                                                <td>
            <span class="badge badge-dot">
              <i class="bg-info"></i>

            </span>
                                                </td>


                                                <td class="float-end">
                                                    <a href="/configure-payment-gateway?api_name=stripe" type="button" class="btn bg-gradient-dark btn-md"><?php echo e(__('Configure')); ?></a>

                                                </td>
                                            </tr>



                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                            <div class="card-body p-3">
                                <div class="row">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card h-100">
                    <div class="card-header pb-0 p-3">
                        <div class="row">
                            <div class="col-6 d-flex align-items-center">
                                <h6 class="mb-0"><?php echo e(__('Workspaces')); ?></h6>
                            </div>
                            <div class="col-6 text-end">
                                <a href="/workspaces" class="btn btn-outline-primary btn-sm mb-0"><?php echo e(__('View All')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-3 pb-0">
                        <ul class="list-group">

                            <?php $__currentLoopData = $recent_workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspaces): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                                    <div class="d-flex flex-column">
                                        <h6 class="mb-1 text-dark font-weight-bold text-sm"><?php echo e($workspaces->name); ?></h6>
                                        <span class="text-xs"><?php echo e($workspaces->created_at); ?></span>
                                    </div>

                                </li>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7 mt-4">
                <div class="card mb-4">
                    <div class="card-header pb-0">
                        <h6><?php echo e(__('Users')); ?></h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('User')); ?></th>


                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Account Created')); ?></th>
                                    <th class="text-secondary opacity-7"></th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $recent_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-2 py-1">
                                                <div>
                                                    <?php if(empty($user['photo'])): ?>
                                                        <div class="avatar avatar-md bg-gradient-dark border-radius-md p-2 ">
                                                            <h1 class="text-white text-sm"><?php echo e($user->first_name['0']); ?></h1>
                                                        </div>
                                                    <?php else: ?>

                                                        <img src="<?php echo e(asset($user['photo'])); ?>"alt="bruce" class="w-100 border-radius-lg shadow-sm">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="d-flex flex-column justify-content-center px-3" >
                                                    <h6 class="mb-0 text-sm"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h6>
                                                    <p class="text-xs text-secondary mb-0"><?php echo e($user->email); ?></p>
                                                </div>
                                            </div>
                                        </td>


                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->created_at); ?></span>
                                        </td>
                                        <td class="align-middle">
                                            <div class="ms-auto text-end">

                                                <a class="btn btn-link text-dark px-3 mb-0" href="/user-profile?id=<?php echo e($user->id); ?>"><i class="fas fa-file-alt text-dark me-2" aria-hidden="true"></i><?php echo e(__('View')); ?></a>

                                            </div>

                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-5 mt-4">
                <div class="card">
                    <div class="card-header pb-0 px-3">
                        <h6 class="mb-0"><?php echo e(__('Subscription Plans')); ?></h6>
                    </div>
                    <div class="card-body pt-4 p-3">
                        <ul class="list-group">

                            <?php $__currentLoopData = $recent_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">
                                    <div class="d-flex flex-column">
                                        <h6 class="mb-3 text-sm"><?php echo e($plans->name); ?></h6>
                                        <span class="mb-2 text-xs"><?php echo e(__('Monthly Price')); ?> <span class="text-dark font-weight-bold ms-sm-2">$ <?php echo e($plans->price_monthly); ?></span></span>
                                        <span class="mb-2 text-xs"><?php echo e(__('Yearly Price')); ?> <span class="text-dark ms-sm-2 font-weight-bold"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="e98c9d818887a98f808b8c9bc78a8684">$ <?php echo e($plans->price_yearly); ?></a></span></span>

                                    </div>
                                    <div class="ms-auto text-end">
                                        <a href="/subscription-plan?id=<?php echo e($plans->id); ?>" class="btn btn-link text-dark text-gradient px-3 mb-0" href="javascript:;"><i class="far fa-trash-alt me-2"></i>Edit</a>
                                        <a  href="/delete/subscription-plan/<?php echo e($plans->id); ?>" class="btn btn-link text-danger px-3 mb-0" href="javascript:;"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Delete</a>
                                    </div>
                                </li>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script>
        "use strict"
        $(function () {
            $('.todo_checkbox').on('change',function () {
                let that = $(this);
                if(this.checked)
                {
                    $.post('/todos/change-status',{
                        id: that.attr('data-id'),
                        status: 'Completed',
                        _token: '<?php echo e(csrf_token()); ?>',
                    });
                }
                else{
                    $.post('/todos/change-status',{
                        id: that.attr('data-id'),
                        status: 'Not Completed',
                        _token: '<?php echo e(csrf_token()); ?>',
                    });
                }
            });
        });
    </script>
    <script>

        $(function () {
            $('.goal_checkbox').on('change',function () {
                let that = $(this);
                if(this.checked)
                {
                    $.post('/goals/change-status',{
                        id: that.attr('data-id'),
                        status: 'Completed',
                        _token: '<?php echo e(csrf_token()); ?>',
                    });
                }
                else{
                    $.post('/goals/change-status',{
                        id: that.attr('data-id'),
                        status: 'Not Completed',
                        _token: '<?php echo e(csrf_token()); ?>',
                    });
                }
            });
        });
    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.super-admin-portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/super-admin-dashboard.blade.php ENDPATH**/ ?>