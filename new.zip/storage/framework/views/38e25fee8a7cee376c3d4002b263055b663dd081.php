<?php $__env->startSection('content'); ?>


    <div class="container-fluid my-3 py-3">
        <div class="row mb-5">


            <div class="col-lg-8 mt-lg-0 ">
                <!-- Card Profile -->

                <!-- Card Basic Info -->





                    <div class="card " id="basic-info">
                        <div class="card-header">

                            <div class="float-end">
                                <a  href="/projects" type="button" class="btn btn-sm bg-gradient-dark mt-4">
                                    <?php echo e(__('Go back to Project List')); ?>

                                </a>

                            </div>
                            <h5 class="mt-4"><?php echo e($project->title); ?></h5>



                        </div>
                        <div class="card-body">
                            <div class="card-body pt-0">
                                <div class="row">
                                    <div class="col">
                                        <h6><?php echo e(__('Start date')); ?></h6>
                                        <span>
                                            <div class="ms-auto">
                            <span class="badge badge-sm bg-gradient-success"><?php echo e($project->start_date); ?></span>
                        </div>

                                        </span>
                                    </div>
                                    <div class="col">
                                        <h6><?php echo e(__('End date')); ?></h6>
                                        <span>
                                            <div class="ms-auto">
                            <span class="badge badge-sm bg-gradient-dark"><?php echo e($project->end_date); ?></span>
                        </div>

                                        </span>
                                    </div>


                                </div>
                                <h6 class="mt-4"><?php echo e(__('Summary')); ?></h6>
                                <div class="d-flex bg-gray-100 border-radius-lg p-3 mb-4">
                                    <p class="my-auto">
                                        <span class="text-secondary text-sm me-1"></span><?php echo e($project->summary); ?><span class="text-secondary text-sm ms-1"></span>
                                    </p>

                                </div>



                                <h6 class="mt-4"><?php echo e(__('Description')); ?></h6>
                                <p class="mt-4 mb-0"><?php echo $project->description; ?></p>
                            </div>

                        </div>





                </form>



            </div>


        </div>
            <div class="col-md-4">
                <div class="card" id="additional_settings">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="mb-0"><?php echo e(__('Project Todo list')); ?></h6>

                            </div>



                            <div class="col-md-6 d-flex justify-content-end ">
                                <a  href="/add-task?for=project" type="button" class="btn btn-sm bg-gradient-dark mt-4"><?php echo e(__('Add To-dos')); ?></a>

                            </div>

                        </div>
                        <hr class="horizontal dark mb-0">
                    </div>
                    <div class="card-body p-3 pt-0">
                        <ul class="list-group list-group-flush" data-toggle="checklist">
                            <?php $__currentLoopData = $todos_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <li class="list-group-item border-0 flex-column align-items-start ps-0 py-0 mb-3">
                                    <div class="checklist-item checklist-item-primary ps-2 ms-3">
                                        <div class="d-flex align-items-center">
                                            <div class="form-check">
                                                <input class="form-check-input todo_checkbox" type="checkbox"
                                                       data-id="<?php echo e($todo->id); ?>"

                                                       <?php if($todo->completed): ?> checked <?php endif; ?>

                                                >
                                            </div>
                                            <h6 class="mb-0 text-dark font-weight-bold text-sm"><?php echo e($todo->title); ?></h6>  <div class="float-end">

                                                <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/delete/today-todo/<?php echo e($todo->id); ?>"><i class="far fa-trash-alt me-2"></i></a>
                                                <a class="btn btn-link text-dark px-3 mb-0" href="/add-task/?id=<?php echo e($todo->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i></a>
                                                </a>

                                            </div>

                                        </div>
                                        <div class="d-flex align-items-center ms-4 mt-3 ps-1">
                                            <div>
                                                <p class="text-xs mb-0 text-secondary font-weight-bold"><?php echo e(__('Date')); ?></p>
                                                <span class="text-xs font-weight-bolder"><?php echo e($todo->date); ?></span>
                                            </div>

                                        </div>
                                    </div>

                                    <hr class="horizontal dark mt-4 mb-0">
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </ul>
                    </div>
                </div>
            </div>

    </div>

<?php $__env->stopSection(); ?>

        <?php $__env->startSection('script'); ?>


            <script>
                "use strict"
                $(function () {
                    $('.todo_checkbox').on('change',function () {
                        let that = $(this);
                        if(this.checked)
                        {
                            $.post('/todos/change-status',{
                                id: that.attr('data-id'),
                                status: 'Completed',
                                _token: '<?php echo e(csrf_token()); ?>',
                            });
                        }
                        else{
                            $.post('/todos/change-status',{
                                id: that.attr('data-id'),
                                status: 'Not Completed',
                                _token: '<?php echo e(csrf_token()); ?>',
                            });
                        }
                    });
                });
            </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/projects/view-project.blade.php ENDPATH**/ ?>