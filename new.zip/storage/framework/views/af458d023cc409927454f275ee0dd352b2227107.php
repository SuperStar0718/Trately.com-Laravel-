<?php $__env->startSection('content'); ?>
    <div class="row d-print-none">


        <div class="col text-center">
            <h5 class="mb-2 text-secondary fw-bolder">
                <?php echo e(__('PEST Analysis of')); ?>

                <?php if(!empty($model)): ?>
                    <?php echo e($model->company_name); ?>

                <?php endif; ?>

            </h5>
        </div>

    </div>
    <div class="row mt-3">
        <div class="col-lg-1 col-md-1 pt-5 pt-lg-0 ms-lg-2 text-center d-print-none">


            <a href="/write-pest?id=<?php echo e($model->id); ?>" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Edit">
                <i class="fas fa-pen p-2"></i>
            </a>
            <a href="#" onclick="window.print()" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="Print">
                <i class="fas fa-print p-2"></i>
            </a>
            <a href="/pest-list" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="List">
                <i class="fas fa-ellipsis-h p-2"></i>
            </a>
        </div>
        <div class="col-md-10">
            <div class="card-group">

                <div class="card">

                    <div class="card-header fw-bolder text-center text-white bg-lightblue">
                        <h1 class="text-white">P</h1>
                        <?php echo e(__('Political')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->political); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder text-center text-white bg-info">
                        <h1 class="text-white">E</h1>
                        <?php echo e(__('Economic')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->economic); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder  text-center bg-darkblue text-white">
                        <h1 class="text-white">S</h1>
                        <?php echo e(__('Social')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->social); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder text-center text-white  bg-extradarkblue">
                        <h1 class="text-white">T</h1>
                        <?php echo e(__('Technological')); ?>

                    </div>
                    <div class="card-body">
                        <p>  <?php if(!empty($model)): ?>
                                <?php echo clean($model->technological); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/pest/view-pest.blade.php ENDPATH**/ ?>