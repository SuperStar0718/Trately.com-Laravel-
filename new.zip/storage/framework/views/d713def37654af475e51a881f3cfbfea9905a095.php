<?php $__env->startSection('content'); ?>


    <div class="page-header mb-4 border-radius-xl" style="background-image: url('/learn.jpg');">
        <span class="mask bg-gradient-dark"></span>
        <div class="container">
            <div class="row">
                <p class="col-lg-6 my-auto">

                <h5 class="text-white fadeIn2 fadeInBottom mt-4">Learn Something New
                </h5>
                <p class="lead text-white opacity-8 fadeIn3 fadeInBottom"> “Learning never exhausts the mind.”


                </p>
                <p class="lead text-white opacity-8 fadeIn3 fadeInBottom"> – Leonardo da Vinci</p>
                <p class="lead text-white opacity-8 fadeIn3 fadeInBottom"> “Want to earn more? Learn More”


                </p>


            </div>
            <a href="/add-tolearn" type="button" class="btn bg-gradient-light">Add Things to Learn</a>

        </div>


    </div>


    <div class="row">
        <div class="col-md-12 mt-4">
            <div class="card">
                <div class="card-header pb-0 px-3">
                    <h6 class="mb-0">To Learns List</h6>
                </div>
                <div class="card-body pt-4 p-3">
                    <ul class="list-group">

                        <?php $__currentLoopData = $to_learns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to_learn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item border-0 d-flex p-4 mb-2 mt-3 bg-gray-100 border-radius-lg">
                                <div class="d-flex flex-column">
                                    <h6 class="mb-3 text-sm"><?php echo e($to_learn->title); ?></h6>

                                    <span class="text-xs">Date to Finish: <span class="text-dark ms-sm-2 font-weight-bold">12 3 2022</span></span>
                                </div>
                                <div class="ms-auto text-end">

                                    <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/delete/to-learn/<?php echo e($to_learn->id); ?>"><i class="far fa-trash-alt me-2"></i>Delete</a>
                                    <a class="btn btn-link text-dark px-3 mb-0" href="/add-tolearn?id=<?php echo e($to_learn->id); ?>"><i class="fas fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Edit</a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </ul>
                </div>
            </div>
        </div>

    </div>










<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>



    <script>


        $(function () {




            // $('#content').redactor(
            //     {
            //         minHeight: 200, // pixels
            //         plugins: ['fontcolor']
            //     }
            // );
            let $date = $("#date");
            $date.flatpickr({


                dateFormat: "Y-m-d",
            });

            $('#editor').summernote(
                {
                    tabsize: 2,
                    height: 200,

                }
            );













        });
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/actions/tolearn.blade.php ENDPATH**/ ?>