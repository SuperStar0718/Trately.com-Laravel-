<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert bg-pink-light text-danger">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="/activate-license" >
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><?php echo e(__('Purchase Code')); ?></label>
            <input type="text" name="purchase_code" class="form-control" value="<?php echo e($settings['purchase_code'] ?? ''); ?>">
            <div id="emailHelp" class="form-text"><?php echo e(__('Get the purchase code from codecanyon and submit here')); ?></div>
        </div>

        <?php echo csrf_field(); ?>

        <button type="submit" class="btn btn-info"><?php echo e(__('Submit')); ?></button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super-admin-portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/asbwo9e2/trately.com/resources/views/super-admin/activate-license.blade.php ENDPATH**/ ?>