<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="page-header min-height-150 border-radius-xl mt-4">
            <span class="mask bg-gradient-primary opacity-6"></span>
        </div>
        <div class="card card-body blur shadow-blur mx-4 mt-n6 overflow-hidden">
            <div class="row gx-4">
                <div class="col-auto">
                    <div class="avatar avatar-xl position-relative">
                        <?php if(empty($focus_user['photo'])): ?>
                            <img src="<?php echo e(PUBLIC_DIR); ?>/img/user-avatar-placeholder.png" class="w-100 border-radius-lg shadow-sm">
                        <?php else: ?>

                            <img src="<?php echo e(asset($focus_user->photo)); ?>"alt="bruce" class="w-100 border-radius-lg shadow-sm">
                        <?php endif; ?>

                    </div>
                </div>
                <div class="col-auto my-auto">
                    <div class="h-100">
                        <h5 class="mb-1">
                            <?php echo e($focus_user->first_name); ?> <?php echo e($focus_user->last_name); ?>


                        </h5>
                        <p class="mb-0 font-weight-bold text-sm">
                           <?php echo e($focus_user->email); ?>

                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 my-sm-auto ms-sm-auto me-sm-0 mx-auto mt-3">
                    <div class="nav-wrapper position-relative end-0">
                        <ul class="nav nav-pills nav-fill p-1 bg-transparent" role="tablist">



                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12 col-md-8">
                <div class="card h-100">
                    <div class="card-header pb-0 p-3">
                        <div class="row">
                            <div class="col-md-8 d-flex align-items-center">
                                <h6 class="mb-0"><?php echo e(__('Profile Information')); ?></h6>
                            </div>
                            <div class="col-md-4 text-end">

                            </div>
                        </div>
                    </div>
                    <div class="card-body p-3">

                        <ul class="list-group">

                            <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark"><?php echo e(__('Full Name:')); ?></strong> <?php echo e($focus_user->first_name); ?> <?php echo e($focus_user->last_name); ?></li>
                            <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark"><?php echo e(__('Mobile Number:')); ?></strong> <?php echo e($focus_user->mobile_number); ?></li>
                            <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark"><?php echo e(__('Email:')); ?></strong>  <?php echo e($focus_user->email); ?></li>
                            <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark"><?php echo e(__('Account Created:')); ?></strong> <?php echo e($focus_user->created_at); ?></li>

                        </ul>
                    </div>
                </div>
            </div>




        </div>

    </div>




<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.super-admin-portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/super-admin/user-profile.blade.php ENDPATH**/ ?>