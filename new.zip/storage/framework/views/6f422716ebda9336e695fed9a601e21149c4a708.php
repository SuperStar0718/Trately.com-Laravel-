<?php $__env->startSection('content'); ?>



    <div class="col-lg-12 col-12 mt-4 mt-lg-0">
        <div class="card">
            <div class="card-header pb-0 p-3">
                <div class="row mb-4">
                    <div class="col-6 d-flex align-items-center">
                        <h6 class="mb-0"><?php echo e($note->topic); ?></h6>
                    </div>
                    <div class="col-6 text-end">
                        <a href="/add-note?id=<?php echo e($note->id); ?>" class="btn btn-outline-primary btn-sm mb-0">Edit</a>
                        <a href="/notes" class="btn btn-outline-primary btn-sm mb-0">List Notes</a>
                        <a href="#" onclick="window.print()" class="btn btn-outline-primary btn-sm mb-0">Print</a>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="d-flex bg-gray-100 border-radius-lg p-3 mb-4">
                    <h4 class="my-auto">
                        <span class="text-secondary text-sm me-1"></span><?php echo e($note->title); ?><span class="text-secondary text-sm ms-1"></span>
                    </h4>

                </div>
                <div class="">
                    <?php echo $note->notes; ?>

                </div>

            </div>



        </div>
    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/actions/view-note.blade.php ENDPATH**/ ?>