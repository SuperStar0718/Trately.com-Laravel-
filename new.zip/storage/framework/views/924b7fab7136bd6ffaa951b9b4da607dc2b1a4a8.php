<?php $__env->startSection('content'); ?>



    <div class="page-header mb-4 border-radius-xl" style="background-image: url('https://images.unsplash.com/photo-1552793494-111afe03d0ca?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=1920&amp;q=80');">
        <span class="mask bg-gradient-dark"></span>
        <div class="container">
            <div class="row">


                <div class="col-lg-6 my-auto">

                    <h5 class="text-white fadeIn2 fadeInBottom mt-4">“Sooner or later, those who win are those who think they can.”
                    </h5>
                    <p class="lead text-white opacity-8 fadeIn3 fadeInBottom"> — Paul Tournier</p>
                </div>
            </div>
            <a  href="/create-project" type="button" class="btn bg-gradient-light">Create your Dream Project</a>


        </div>
    </div>


    <div class="container-fluid py-4">
        <section class="py-3">
            <div class="row">
                <div class="col-md-8 me-auto text-left">
                    <h5>List of your Awesome Projects</h5>
                    <p>This is the paragraph where you can write more details about your projects. Keep you user engaged by providing meaningful information.</p>
                </div>
            </div>
            <div class="row mt-lg-4 mt-2">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card card-blog ">
                            <div class="card-body p-3">
                                <div class="d-flex">
                                    <div class="avatar avatar-xl bg-gradient-dark border-radius-md p-2">
                                        <h1 class="text-white"><?php echo e($project->title['0']); ?></h1>
                                    </div>
                                    <div class="ms-3 my-auto">
                                        <h6><?php echo e($project->title); ?></h6>

                                    </div>



                                </div>

                                <p class="text-sm mt-3"> <?php echo e($project->summary); ?> </p>
                                <hr class="horizontal dark">
                                <div class="row">
                                    <div class="col-6 ">
                                        <h6 class="text-sm mb-0"><?php echo e($project->start_date); ?></h6>
                                        <p class="text-secondary text-sm font-weight-bold mb-0">Start date</p>
                                    </div>
                                    <div class="col-6 text-end">
                                        <h6 class="text-sm mb-0"><?php echo e($project->end_date); ?></h6>
                                        <p class="text-secondary text-sm font-weight-bold mb-0">Due date</p>
                                    </div>
                                    <div class="btn-group">
                                        <a href="/view-project?id=<?php echo e($project->id); ?>" type="button" class="btn bg-gradient-dark mt-3">View</a>
                                        <a href="/create-project?id=<?php echo e($project->id); ?>" type="button" class="btn bg-gradient-secondary mt-3">Edit</a>
                                        <a href="/delete/project/<?php echo e($project->id); ?>" type="button" class="btn bg-gradient-primary mt-3">Delete</a>

                                    </div>
                                </div>


                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body d-flex flex-column justify-content-center text-center">
                            <a href="/create-project">
                                <i class="fa fa-plus text-secondary mb-3"></i>
                                <h5 class=" text-secondary"> New project </h5>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/projects/projects.blade.php ENDPATH**/ ?>