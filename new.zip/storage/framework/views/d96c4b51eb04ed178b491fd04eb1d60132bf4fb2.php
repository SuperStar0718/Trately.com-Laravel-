<?php $__env->startSection('content'); ?>
    <div class="row">
        <h5 class=" col fw-bolder">
            <?php echo e($note->topic); ?>

        </h5>
        <div class="col text-end mb-3">
            <a href="/add-note?id=<?php echo e($note->id); ?>" class="btn btn-info btn-sm mb-0"><?php echo e(__('Edit')); ?></a>
            <a href="/delete/note/<?php echo e($note->id); ?>" class="btn btn-warning btn-sm mb-0"><?php echo e(__('Delete')); ?></a>
        </div>
    </div>
    <div class="card">
        <div class="row">
            <div class="col-md-6 ms-auto text-center mt-3 ">
                <h2 class="mt-6 ms-3"><?php echo e($note->title); ?></h2>
                <?php if(!empty($users[$note->admin_id]->photo)): ?>
                    <a href="javascript:" class=" mt-4 avatar rounded-circle border border-secondary">
                        <img alt="" class="p-1" src="<?php echo e(PUBLIC_DIR); ?>/uploads/<?php echo e($users[$note->admin_id]->photo); ?>">
                    </a>
                <?php else: ?>
                    <?php if(!empty($users[$note->admin_id])): ?>
                    <div class="avatar   mt-4 rounded-circle bg-purple-light  border-radius-md p-2">
                        <h6 class="text-purple mt-1">

                                <?php echo e($users[$note->admin_id]->first_name[0]); ?><?php echo e($users[$note->admin_id]->last_name[0]); ?>


                        </h6>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
                <a href="/profile" class=" nav-link text-body font-weight-bold px-0">
                        <span class="d-sm-inline d-none "> <?php if(isset($users[$note->admin_id])): ?>
                                <?php echo e($users[$note->admin_id]->first_name); ?>  <?php echo e($users[$note->admin_id]->last_name); ?>

                            <?php endif; ?>
                        </span>
                </a>
                <p>
                    <?php echo e((\App\Supports\DateSupport::parse($note->created_at))->format(config('app.date_format'))); ?>


                </p>
            </div>
            <div class="col-md-6">
                <div class="card-header p-0 mx-3 mt-3 position-relative z-index-1">
                    <a href="javascript:" class="d-block">
                        <?php if(!empty($note->cover_photo)): ?>
                            <img src="<?php echo e(PUBLIC_DIR); ?>/uploads/<?php echo e($note->cover_photo); ?>" class="img-fluid border-radius-lg">

                        <?php endif; ?>



                    </a>
                </div>

            </div>
        </div>
        <div class="card-body pt-2">
            <div class="mb-4">
                <?php echo $note->notes; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/actions/view-note.blade.php ENDPATH**/ ?>