<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>



 <header class="bg-gradient-dark">
        <div class="page-header min-vh-100" style="background-image: url('<?php echo e(PUBLIC_DIR); ?>/img/cover2.jpg');">

            <span class="mask bg-brown opacity-8"></span>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-7 d-flex justify-content-center flex-column">
                        <h1 class="text-warning  display-1  fw-bolder mt-4">Focus on Your Dreams</h1>
                        <h1 class="mb-4 display-6 text-white">Unleash your super power</h1>
                        <p class="text-white-50 pe-5 me-5">The time is to focus in yourself. Selfcare is not Selfish. </p>
                        <div class="buttons">
                            <button type="button" class="btn btn-md bg-pink-light text-dark mt-4">Get Started</button>
                            <button type="button" class="btn btn-md  btn-outline-light  text-white shadow-none mt-4">Read more</button>
                        </div>
                    </div>
                </div>


            </div>

        </div>
        <div class="position-absolute w-100 bottom-0">
            <svg width="100%" viewBox="0 -1 1920 166" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>wave-up</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g transform="translate(0.000000, 5.000000)" fill="#FFFFFF" fill-rule="nonzero">
                        <g id="wave-up" transform="translate(0.000000, -5.000000)">
                            <path d="M0,70 C298.666667,105.333333 618.666667,95 960,39 C1301.33333,-17 1621.33333,-11.3333333 1920,56 L1920,165 L0,165 L0,70 Z"></path>
                        </g>
                    </g>
                </g>
            </svg>
        </div>

    </header>




 

    <section class="">
        <div class="container">
            <div class="row">
                <div class="col-md-12 ms-auto me-auto text-center">
                    <div class="p-3 info-hover-warning">
                        <div class="icon icon-shape bg-purple-light shadow icon-shape-circle ">
                            <i class="fa fa-pen text-purple"></i>
                        </div>
                    </div>
                    <h3 class=" display-3 fw-bolder  text-dark mb-3 mt-2">Take control of your life</h3>
                    <h3 class="text-warning mb-3 ">Explore the features and benefits</h3>

                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-4 ms-auto my-auto">
                    <div class="cursor-pointer">
                        <div class="card card-background tilt" data-tilt="">
                            <div class="full-background" style="background-image: url('<?php echo e(PUBLIC_DIR); ?>/img/feature2.jpg')"></div>
                            <div class="card-body pt-7 text-center">
                                <div class="icon icon-lg up mb-3">
                                    <svg width="40px" height="40px" viewBox="0 0 40 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <title>chart-pie-35</title>
                                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <g transform="translate(-1720.000000, -742.000000)" fill="#FFFFFF" fill-rule="nonzero">
                                                <g transform="translate(1716.000000, 291.000000)">
                                                    <g transform="translate(4.000000, 451.000000)">
                                                        <path d="M21.6666667,18.3333333 L39.915,18.3333333 C39.11,8.635 31.365,0.89 21.6666667,0.085 L21.6666667,18.3333333 Z" opacity="0.602864583"></path>
                                                        <path d="M20.69,21.6666667 L7.09833333,35.2583333 C10.585,38.21 15.085,40 20,40 C30.465,40 39.0633333,31.915 39.915,21.6666667 L20.69,21.6666667 Z"></path>
                                                        <path d="M18.3333333,19.31 L18.3333333,0.085 C8.085,0.936666667 0,9.535 0,20 C0,24.915 1.79,29.415 4.74166667,32.9016667 L18.3333333,19.31 Z"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </div>
                                <h1 class="text-white up mb-0">Set Goals!</h1>
                                <p class="lead up">Achieve Goals</p>
                                <button type="button" class="btn btn-white btn-lg mt-3 up">Get Started</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 me-auto my-auto ms-md-5">
                    <div class="p-3 info-horizontal d-flex">
                        <div>
                            <h5>1. Set Concise Goals</h5>
                            <p>
                                Lorem ipsum dolor sit amet. Aut libero sint est repudiandae maxime aut vitae dolorem nam similique perferendis et illum quos eos quidem esse aut omnis dolor.

                            </p>
                        </div>
                    </div>
                    <div class="p-3 info-horizontal d-flex">
                        <div>
                            <h5>2. Plan for your Goals</h5>
                            <p>
                                Est distinctio voluptatibus qui alias error est ipsum blanditiis eos facere voluptas est officia voluptatem et veritatis ipsa aut cumque maxime.
                            </p>
                        </div>
                    </div>
                    <div class="p-3 info-horizontal d-flex">
                        <div>
                            <h5>3. Achive Goals</h5>
                            <p>
                                Qui ullam dolorum ut cupiditate soluta eos illum corporis eum quas numquam et maiores libero vel velit modi.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="dark my-md-6 mt-2 mx-7">
            <div class="row">
                <div class="col-md-5 ms-auto my-auto">
                    <div class="p-3 info-horizontal d-flex">
                        <div>
                            <h5>1. Write Morning Pages</h5>
                            <p>
                                Aut facere excepturi ex quis dicta cum perferendis quae et omnis dolorem et dolores fugiat sit cumque recusandae. Sit velit nostrum vel vero consequatur ea culpa veritatis.

                            </p>
                        </div>
                    </div>
                    <div class="p-3 info-horizontal d-flex">
                        <div>
                            <h5>2. Take Notes</h5>
                            <p>
                                Sit culpa quasi eum beatae odio sit velit debitis et consequatur magnam et impedit nesciunt ab libero deleniti.

                            </p>
                        </div>
                    </div>
                    <div class="p-3 info-horizontal d-flex">
                        <div>
                            <h5>3. Learn New Things</h5>
                            <p>
                                Aut libero sint est repudiandae maxime aut vitae dolorem nam similique perferendis et illum quos eos quidem esse aut omnis dolor.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 me-auto my-auto ms-md-5">
                    <div class="cursor-pointer">
                        <div class="card card-background tilt" data-tilt="">
                            <div class="full-background" style="background-image: url('<?php echo e(PUBLIC_DIR); ?>/img/feature3.jpg')"></div>
                            <div class="card-body pt-7 text-center">
                                <div class="icon icon-lg up mb-3">
                                    <svg width="40px" height="40px" viewBox="0 0 46 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <title>customer-support</title>
                                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <g transform="translate(-1717.000000, -291.000000)" fill="#FFFFFF" fill-rule="nonzero">
                                                <g transform="translate(1716.000000, 291.000000)">
                                                    <g transform="translate(1.000000, 0.000000)">
                                                        <path d="M45,0 L26,0 C25.447,0 25,0.447 25,1 L25,20 C25,20.379 25.214,20.725 25.553,20.895 C25.694,20.965 25.848,21 26,21 C26.212,21 26.424,20.933 26.6,20.8 L34.333,15 L45,15 C45.553,15 46,14.553 46,14 L46,1 C46,0.447 45.553,0 45,0 Z" opacity="0.59858631"></path>
                                                        <path d="M22.883,32.86 C20.761,32.012 17.324,31 13,31 C8.676,31 5.239,32.012 3.116,32.86 C1.224,33.619 0,35.438 0,37.494 L0,41 C0,41.553 0.447,42 1,42 L25,42 C25.553,42 26,41.553 26,41 L26,37.494 C26,35.438 24.776,33.619 22.883,32.86 Z"></path>
                                                        <path d="M13,28 C17.432,28 21,22.529 21,18 C21,13.589 17.411,10 13,10 C8.589,10 5,13.589 5,18 C5,22.529 8.568,28 13,28 Z"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </div>
                                <h1 class="text-white up mb-0">Take Notes</h1>
                                <p class="lead up">Learn Better</p>
                                <button type="button" class="btn btn-white btn-lg mt-3 up">Get Started</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="bg-purple-light position-relative overflow-hidden">

        <div class="position-absolute w-100 z-inde-1 top-0 mt-n3">
            <svg width="100%" viewBox="0 -2 1920 157" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>wave-down</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g fill="#FFFFFF" fill-rule="nonzero">
                        <g id="wave-down">
                            <path d="M0,60.8320331 C299.333333,115.127115 618.333333,111.165365 959,47.8320321 C1299.66667,-15.5013009 1620.66667,-15.2062179 1920,47.8320331 L1920,156.389409 L0,156.389409 L0,60.8320331 Z" id="Path-Copy-2" transform="translate(960.000000, 78.416017) rotate(180.000000) translate(-960.000000, -78.416017) "></path>
                        </g>
                    </g>
                </g>
            </svg>
        </div>
        <div class="container py-lg-10 py-7">
            <div class="row">
                <div class="col-lg-6 d-flex justify-content-center flex-column">
                    <div id="carouselExampleIndicator" class="carousel slide py-7" data-bs-ride="carousel">
                        <div class="carousel-indicators justify-content-start ms-0">
                            <a href="javascript:;">
                                <img src="<?php echo e(PUBLIC_DIR); ?>/img/av1.jpg" alt="..." class="avatar avatar-sm avatar-scale-up shadow border-0 active" data-bs-target="#carouselExampleIndicator" data-bs-slide-to="0">
                                <span class="text-white mx-2">&#124;</span>
                            </a>
                            <a href="javascript:;">
                                <img src="<?php echo e(PUBLIC_DIR); ?>/img/av2.jpg" alt="..." class="avatar avatar-sm avatar-scale-up shadow border-0 active" data-bs-target="#carouselExampleIndicator" data-bs-slide-to="1">
                                <span class="text-white mx-2">&#124;</span>
                            </a>
                            <a href="javascript:;">
                                <img src="<?php echo e(PUBLIC_DIR); ?>/img/av3.jpg" alt="..." class="avatar avatar-sm avatar-scale-up shadow border-0 active" data-bs-target="#carouselExampleIndicator" data-bs-slide-to="2">
                            </a>
                        </div>
                        <div class="carousel-inner">
                            <h2 class="text-black-50 fw-bolder display-1 mb-1">Partners</h2>
                            <p class="text-purple opacity-8 mb-1">Lorem ipsum dolor sit amet.!</p>
                            <hr class="text-white horizontal opacity-6 mb-4 mt-2 w-25 text-start">
                            <div class="carousel-item active">
                                <h6 class="text-muted opacity-8 pe-5">"Aut libero sint est repudiandae maxime aut vitae dolorem nam similique perferendis et illum quos eos quidem esse aut omnis dolor. Qui ullam dolorum ut cupiditate soluta eos illum corporis eum quas numquam et maiores libero vel velit modi.Est distinctio voluptatibus qui alias error est ipsum blanditiis eos facere voluptas est officia voluptatem et veritatis ipsa aut cumque maxime.
                                    "</h6>
                                <div class="author mt-4">
                                    <div class="name">
                                        <span class="text-warning">Monica Eriksson</span>
                                        <div class="stats">
                                            <small class="text-dark opacity-6">Marketing manager, Orange</small>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="col-md-6 justify-content-center flex-column d-sm-none d-md-none d-lg-flex d-xl-flex">
                    <div class="row justify-content-center d-none d-md-flex">
                        <div class="col-3 mb-4">
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 mt-n4 ms-8 fadeIn2 fadeInBottom">
                                <img src="<?php echo e(PUBLIC_DIR); ?>/img/av8.jpg" alt="Logo Image">
                            </div>
                        </div>
                        <div class="col-4 mb-4">
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 ms-8 mt-n6 fadeIn1 fadeInBottom">
                                <img src="<?php echo e(PUBLIC_DIR); ?>/img/av5.jpg" alt="Logo Image">
                            </div>
                        </div>
                        <div class="col-4 mb-4">
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 ms-6 mt-2 fadeIn3 fadeInBottom">
                                <img src="<?php echo e(PUBLIC_DIR); ?>/img/av7.jpg" alt="Logo Image">
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-end d-none d-md-flex">
                        <div class="col-4 my-4">
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 ms-4 fadeIn1 fadeInBottom">
                                <img class="avatar-img" src="<?php echo e(PUBLIC_DIR); ?>/img/av2.jpg" alt="Image">
                            </div>
                        </div>
                        <div class="col-3 my-4">
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 me-auto fadeIn1 fadeInBottom">
                                <img class="avatar-img" src="<?php echo e(PUBLIC_DIR); ?>/img/av5.jpg" alt="Image">
                            </div>
                        </div>
                        <div class="col-3 my-4">
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 fadeIn3 fadeInBottom ms-3 mt-3">
                                <img class="avatar-img" src="<?php echo e(PUBLIC_DIR); ?>/img/av3.jpg" alt="Image">
                            </div>
                        </div>
                    </div>
                    <div class="row d-none d-md-flex">
                        <div class="col-6">
                            <!-- Logo -->
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 ms-auto mt-5 fadeIn2 fadeInBottom">
                                <img class="avatar-img" src="<?php echo e(PUBLIC_DIR); ?>/img/av1.jpg" alt="Image">
                            </div>
                            <!-- End Logo -->
                        </div>
                        <div class="col-6 mt-6">
                            <!-- Logo -->
                            <div class="d-block bg-white avatar avatar-lg rounded-circle p-3 mx-auto mt-n3 fadeIn3 fadeInBottom">
                                <img class="avatar-img" src="<?php echo e(PUBLIC_DIR); ?>/img/av2.jpg" alt="Image">
                            </div>
                            <!-- End Logo -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="position-absolute w-100 bottom-0">
            <svg width="100%" viewBox="0 -1 1920 166" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>wave-up</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g transform="translate(0.000000, 5.000000)" fill="#FFFFFF" fill-rule="nonzero">
                        <g id="wave-up" transform="translate(0.000000, -5.000000)">
                            <path d="M0,70 C298.666667,105.333333 618.666667,95 960,39 C1301.33333,-17 1621.33333,-11.3333333 1920,56 L1920,165 L0,165 L0,70 Z"></path>
                        </g>
                    </g>
                </g>
            </svg>
        </div>
    </section>



    <section class="my-5 pt-5">
        <div class="container bg-gradient-white">
            <div class="row">

                <div class=" col-md-5">
                    <div class=" p-0 mx-3 mt-3 position-relative z-index-1">
                        <div class="d-block blur-shadow-image">
                            <img src="<?php echo e(PUBLIC_DIR); ?>/img/suc1.jpg" alt="img-blur-shadow" class="img-fluid shadow rounded-3">
                        </div>
                        <div class="colored-shadow" style="background-image: url('<?php echo e(PUBLIC_DIR); ?>/img/feature.jpg');"></div>
                    </div>

                </div>


                <div class="col-md-6 m-auto">
                    <h2 class="display-1 text-warning fw-bolder">Success Story of Emma</h2>
                    <p class="mb-5 mt-4">
                        Est distinctio voluptatibus qui alias error est ipsum blanditiis eos facere voluptas est officia voluptatem et veritatis ipsa aut cumque maxime. Sit culpa quasi eum beatae odio sit velit debitis et consequatur magnam et impedit nesciunt ab libero deleniti.
                        Aut facere excepturi ex quis dicta cum perferendis quae et omnis dolorem et dolores fugiat sit cumque recusandae. Sit velit nostrum vel vero consequatur ea culpa veritatis.

                    </p>

                    <div class="col-4 ps-0 mt-5">
                        <a href="#" class="btn btn-lg bg-brown text-white fw-bolder mb-0 h-100 ">Laern More</a>
                    </div>


                </div>
            </div>
        </div>



        <div class="container mt-5 bg-white">

            <div class="row justify-content-center text-center mt-5">
                <div class="col-md-3 mt-4">
                    <h1 class="text-purple" id="state1" countTo="5234">38000</h1>
                    <h5 class="text-dark">Users</h5>
                    <p>Sit velit nostrum vel vero consequatur ea culpa veritatis.</p>
                </div>
                <div class="col-md-3 mt-4">
                    <h1 class="text-success"><span id="state2" countTo="3400">20</span>+</h1>
                    <h5 class="text-dark">Countries</h5>
                    <p>Aut facere excepturi ex quis dicta cum perferendis.</p>
                </div>
                <div class="col-md-3 mt-4">
                    <h1 class="text-warning"><span id="state3" countTo="24">0</span>/7</h1>
                    <h5 class="text-dark">Support</h5>
                    <p>Velit nostrum vel vero consequatur ea culpa veritatis.</p>
                </div>
            </div>
        </div>
        <div class="position-absolute w-100 z-inde-1 ">
            <svg width="100%" viewBox="0 -2 1920 157" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>wave-down</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g fill="#FFFFFF" fill-rule="nonzero">
                        <g id="wave-down">
                            <path d="M0,60.8320331 C299.333333,115.127115 618.333333,111.165365 959,47.8320321 C1299.66667,-15.5013009 1620.66667,-15.2062179 1920,47.8320331 L1920,156.389409 L0,156.389409 L0,60.8320331 Z" id="Path-Copy-2" transform="translate(960.000000, 78.416017) rotate(180.000000) translate(-960.000000, -78.416017) "></path>
                        </g>
                    </g>
                </g>
            </svg>
        </div>

        <section class="py-7 bg-pink-light mt-5 overflow-hidden">

            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="row justify-content-start">

                            <div class="info">

                                <h1 class="display-1  text-black-50 fw-bolder">Lisa's Morning Routine</h1>
                                <p class="mb-4">
                                    Aut facere excepturi ex quis dicta cum perferendis quae et omnis dolorem et dolores fugiat sit cumque recusandae. Sit velit nostrum vel vero consequatur ea culpa veritatis.Est distinctio voluptatibus qui alias error est ipsum blanditiis eos facere voluptas est officia voluptatem et veritatis ipsa aut cumque maxime. Sit culpa quasi eum beatae odio sit velit debitis et consequatur magnam et impedit nesciunt ab libero deleniti.
                                </p>
                            </div>

                            <span class="mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                </svg>
                            <span>
                                 Practice Five minute journal
                            </span>

                        </span>
                            <span class="mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                </svg>
                            <span>
                                 Create Goals
                            </span>

                        </span>
                            <span class="mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                </svg>
                            <span>
                                 Plan for your goals
                            </span>

                        </span>
                            <span class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                                </svg>
                            <span>
                                 To-dos for goals
                            </span>

                        </span>




                        </div>
                        <div class="col-4 ps-0 mt-5">
                            <a href="#" class="btn btn-lg bg-brown text-white fw-bolder mb-0 h-100 ">Laern More</a>
                        </div>

                    </div>
                    <div class="col-lg-5 ms-auto mt-lg-0 mt-4">
                        <div class="">
                            <div class=" p-0 mx-3 mt-3 position-relative z-index-1">
                                <div class="d-block blur-shadow-image">
                                    <img src="<?php echo e(PUBLIC_DIR); ?>/img/feature.jpg" alt="img-blur-shadow" class="img-fluid shadow rounded-3">
                                </div>
                                <div class="colored-shadow" style="background-image: url('<?php echo e(PUBLIC_DIR); ?>/img/feature.jpg');"></div>
                            </div>

                        </div>
                    </div>


                </div>


            </div>



        </section>



    <section class="my-5 pt-5">

        <div class="container bg-gradient-white">
            <div class="row">
                <div class="col-md-6 m-auto">
                    <h2 class="display-6 fw-bolder">Awesome Productivity Tips right on your Inbox</h2>
                    <p class="mb-4">
                        Aut facere excepturi ex quis dicta cum perferendis quae et omnis dolorem et dolores fugiat sit cumque recusandae. Sit velit nostrum vel vero consequatur ea culpa veritatis.
                    </p>
                    <form action="/save-email" method="post">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-8">
                                <div class="input-group">
                                    <input type="email" name="email" class="form-control mb-sm-0" placeholder="Email Here...">
                                </div>
                            </div>

                            <?php echo csrf_field(); ?>
                            <div class="col-4 ps-0">
                                <button type="submit" class="btn btn-success fw-bolder mb-0 h-100 position-relative z-index-2">Subscribe</button>
                            </div>
                        </div>

                    </form>


                </div>
                <div class="col-md-5 ms-auto">
                    <div class="position-relative">

                    </div>
                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/frontend/home.blade.php ENDPATH**/ ?>