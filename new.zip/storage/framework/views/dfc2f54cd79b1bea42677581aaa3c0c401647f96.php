<?php $__env->startSection('content'); ?>


    <h3><?php echo e(__('Focus Installation')); ?></h3>
    <p>
        <?php echo e(__('Database import was successful.')); ?>


    </p>


    <p>
        <?php echo e(__('Set your admin profile on the next step.')); ?>

    </p>



    <a class="btn btn-primary mt-3" href="<?php echo e(route('step5')); ?>">
        <?php echo e(__('Continue')); ?>


    </a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/install/step4.blade.php ENDPATH**/ ?>