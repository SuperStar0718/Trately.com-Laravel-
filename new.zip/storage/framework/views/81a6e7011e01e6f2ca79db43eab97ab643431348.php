<?php $__env->startSection('content'); ?>

    <div class="">
        <div class="row">
            <div class="col-12">
                <div class=" ">
                    <div class="">
                        <h4 class="mb-2 fw-bolder">
                            <?php echo e(__('Morning Pages')); ?>

                        </h4>
                        <span>
</span>
                        <p class="mb-0 text-sm">
                            <?php echo e(__('Free your mind from the noise of thousands of thoughts and set your intention for the day. This practice has proven to be the most effective in terms of productivity and mental peace.')); ?>

                        </p>
                        <a  href="/add-five-min-journal" type="button" class="btn bg-gradient-dark mt-4 mb-4"><?php echo e(__('Write your morning page')); ?></a>

                    </div>

                    <div class="">

                        <div class="row">


                            <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 col-12 mt-4 mt-lg-0 mb-4">
                                    <div class="card text-center">
                                        <div class="overflow-hidden position-relative border-radius-lg bg-cover p-3">
                                            <span class="bg-gradient-light opacity-6"></span>
                                            <div class="card-body position-relative z-index-1 d-flex flex-column mt-5">
                                                <h3 class="text-info fw-bolder"><?php echo e(__('')); ?></h3>
                                                <h5 class="text-secondary"><?php echo e($journal->date->format(config('app.date_format'))); ?></h5>
                                                <a class="text-secondary text-sm font-weight-bold mb-0 icon-move-right mt-4" href="/view-journal?id=<?php echo e($journal->id); ?>">
                                                    <?php echo e(__('Read More')); ?>

                                                    <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
                                                </a>
                                                <div class="mt-4">
                                                    <a href="/add-five-min-journal?id=<?php echo e($journal->id); ?>" type="button" class="btn btn-info btn-sm">
                                                        <?php echo e(__('Edit')); ?>


                                                    </a>
                                                    <a href="/delete/journal/<?php echo e($journal->id); ?>" type="button" class=" btn btn-warning btn-sm"><?php echo e(__('Delete')); ?></a>

                                                </div>




                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/gratitude/gratitude.blade.php ENDPATH**/ ?>