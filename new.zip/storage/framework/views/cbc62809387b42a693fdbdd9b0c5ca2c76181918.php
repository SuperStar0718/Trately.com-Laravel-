<?php $__env->startSection('content'); ?>


    <div class="card mb-3 mt-4">

        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">
                    <h6 class="mb-0">Design Email</h6>
                </div>
                <div class="col-md-6 text-right">
                    <a class="btn bg-gradient-dark mb-0" href="/email-campaigns">&nbsp;&nbsp;Go to email campaign</a>
                </div>
            </div>
        </div>
        <div class="card-body  p-3">
            <form action="/email-design" method="post">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Subject</label>
                    <input class="form-control" type="text" name="subject" <?php if(!empty($email_design)): ?> value="<?php echo e($email_design->subject); ?>" <?php endif; ?>  id="example-text-input">
                </div>


                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Message</label>
                    <textarea class="form-control" name="body_text"id="exampleFormControlTextarea1" rows="6"><?php if(!empty($email_design)): ?><?php echo e($email_design->body_text); ?><?php endif; ?> </textarea>
                </div>







                <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($email_design->id); ?>">

                <button class="btn btn-primary" type="submit">Save</button>

            </form>

        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/marketing/email-design.blade.php ENDPATH**/ ?>