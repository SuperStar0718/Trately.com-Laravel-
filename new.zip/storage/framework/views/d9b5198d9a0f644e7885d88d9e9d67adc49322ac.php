<?php $__env->startSection('content'); ?>


    <h3><?php echo e(__('Focus Installation')); ?></h3>
    <p><?php echo e(__('Set your Admin Profile')); ?></p>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('set.admin.profile')); ?>">
        <div class="row">
            <div class="col">
                <div class="mb-3">
                    <label><?php echo e(__('First Name')); ?></label>
                    <input class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>">
                </div>
            </div>
            <div class="col">
                <div class="mb-3">
                    <label><?php echo e(__('Last Name')); ?></label>
                    <input class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>">
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label><?php echo e(__('Email (Username)')); ?></label>
            <input class="form-control" name="email" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="mb-3">
            <label><?php echo e(__('Password')); ?></label>
            <input class="form-control" name="password" type="password">
        </div>
        <div class="mb-3">
            <label><?php echo e(__('Confirm Password')); ?></label>
            <input class="form-control" name="password_confirmation" type="password">
        </div>
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
    </form>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/install/step5.blade.php ENDPATH**/ ?>