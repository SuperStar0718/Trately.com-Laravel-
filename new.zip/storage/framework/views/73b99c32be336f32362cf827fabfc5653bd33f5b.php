<?php $__env->startSection('content'); ?>


    <h3><?php echo e(__('Focus Installation')); ?></h3>
    <p>
        <strong><?php echo e(__('Congratulations!')); ?></strong>
    </p>


    <p>
        <?php echo e(__('Installation is complete.')); ?>

    </p>



    <a class="btn btn-primary mt-3" href="<?php echo e(config('app.url')); ?>">
        <?php echo e(__('Go to Login')); ?>


    </a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/install/step6.blade.php ENDPATH**/ ?>