<?php $__env->startSection('content'); ?>
    <div class="page-header mb-4 border-radius-xl" style="background-image: url('https://images.unsplash.com/photo-1552793494-111afe03d0ca?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=1920&amp;q=80');">
        <span class="mask bg-gradient-dark"></span>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 my-auto">

                    <h5 class="text-white fadeIn2 fadeInBottom mt-4">Taking good notes help you learn more.
                    </h5>

                </div>
            </div>

            <a href="/add-note" type="button" class="btn bg-gradient-light">Take New Note</a>

        </div>
    </div>

    <div class="row">
        <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4">
                <div class="card">


                    <div class="card-body">
                        <p class="text-gradient text-primary text-gradient font-weight-bold text-sm text-uppercase"><?php echo e($note->topic); ?></p>
                        <a href="javascript:;">
                            <h5>
                                <?php echo e($note->title); ?>

                            </h5>
                        </a>
                        <p class="text-muted"><?php echo e($note->updated_at); ?></p>

                        <div class="d-flex mt-5">

                            <a href="/view-note?id=<?php echo e($note->id); ?>" class="btn btn-outline-secondary rounded-circle p-2 mx-2 mb-0" type="button" data-bs-toggle="tooltip" data-bs-placement="top" title="Pause">
                                <i class="fas fa-file p-2"></i>
                            </a>
                            <a href="/add-note?id=<?php echo e($note->id); ?>" class="btn btn-outline-dark rounded-circle p-2 mb-0" type="button" data-bs-toggle="tooltip" data-bs-placement="top" title="Next">
                                <i class="fas fa-pen p-2"></i>
                            </a>
                            <a href="/delete/note/<?php echo e($note->id); ?>" class="btn btn-outline-primary rounded-circle p-2 mx-2 mb-0" type="button" data-bs-toggle="tooltip" data-bs-placement="top" title="Prev">
                                <i class="fas fa-trash p-2"></i>
                            </a>
                        </div>



                    </div>



                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/actions/notes.blade.php ENDPATH**/ ?>