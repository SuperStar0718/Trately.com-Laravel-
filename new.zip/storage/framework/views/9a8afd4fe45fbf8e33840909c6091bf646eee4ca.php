<?php $__env->startSection('content'); ?>


    <div class="nav-wrapper position-relative end-0">



        <ul class="nav nav-pills nav-fill p-1">

            <li class="nav-item">
                <a class="nav-link mb-0 px-0 py-1 <?php if(!$type): ?> active <?php endif; ?>" href="/lead-capture">
                    <i class="ni ni-laptop text-sm me-2"></i> All
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link mb-0 px-0 py-1 active <?php if($type === 'freebies_form'): ?> active <?php endif; ?>" href="/lead-capture?type=freebies_form">
                    <i class="ni ni-badge text-sm me-2"></i> Freebies Form
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link mb-0 px-0 py-1 <?php if($type === 'demo_request_form'): ?> active <?php endif; ?>" href="/lead-capture?type=demo_request_form">
                    <i class="ni ni-laptop text-sm me-2"></i> Demo Request Form
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link mb-0 px-0 py-1 <?php if($type === 'contact_form'): ?> active <?php endif; ?>" href="/lead-capture?type=contact_form">
                    <i class="ni ni-air-baloon text-sm me-2"></i> Contact Form
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link mb-0 px-0 py-1 <?php if($type === 'quote_request_form'): ?> active <?php endif; ?>" href="/lead-capture?type=quote_request_form" role="tab">
                    <i class="ni ni-credit-card text-sm me-2"></i> Quote Request Form
                </a>
            </li>

        </ul>
    </div>

    <div class="col-12 mt-4">
        <div class="card mb-4">
            <div class="card-header pb-0 p-3">
                <div class="row">
                    <div class="col-md-6 d-flex align-items-center">
                        <h6 class="mb-0">Form Properties</h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <a class="btn bg-gradient-dark mb-0" href="/lead-capture-form">&nbsp;&nbsp Create New Form</a>
                    </div>
                </div>
            </div>
            <div class="card-body p-3">
                <div class="row">

                    <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-xl-3 col-md-6 mb-xl-0 mb-4 ">
                            <div class="card card-blog card-plain">

                                <div class="card-body px-1 pb-0 ">

                                    <a href="javascript:;">
                                        <h5>
                                           <?php echo e($form->name); ?>

                                        </h5>
                                    </a>
                                    <p class="mb-4 text-sm">
                                        <?php echo e($form->header_text); ?>


                                    </p>
                                    <div>
                                        <a  href="/manage-lead-form?id=<?php echo e($form->id); ?>" type="button" class="btn btn-primary btn-sm mb-0">Manage</a>
                                        <a href="/lead-capture-form?id=<?php echo e($form->id); ?>" type="button" class="btn btn-outline-primary btn-sm mb-0">Edit</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <div class="col-xl-3 col-md-6 mb-xl-0 mb-4 mt-4" >
                        <div class="card h-100 card-plain border">
                            <div class="card-body d-flex flex-column justify-content-center text-center">
                                <a href="/lead-capture-form?type=<?php echo e($type ?? ''); ?>">
                                    <i class="fa fa-plus text-secondary mb-3"></i>
                                    <h5 class=" text-secondary"> New form </h5>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>











<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/contacts/lead-capture.blade.php ENDPATH**/ ?>