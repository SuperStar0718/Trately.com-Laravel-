<?php $__env->startSection('content'); ?>






    <div class="card">
        <div class="card-body">
            <h4 class="mb-4">Email Flow</h4>

            <ul class="nav nav-tabs nav-tabs-clean mb-3" role="tablist">
                <li class="nav-item"><a class="nav-link <?php if(empty($tab)): ?>active <?php endif; ?>" href="<?php echo e(config('app.url')); ?>/email-flow">All</a></li>
                <li class="nav-item"><a class="nav-link <?php if(($tab ?? null) === 'pending'): ?> active <?php endif; ?>" href="<?php echo e(config('app.url')); ?>/email-flow?tab=pending">Pending</a></li>
                <li class="nav-item">
                    <a class="nav-link <?php if(($tab ?? null) === 'delivered'): ?> active <?php endif; ?>"
                        href="<?php echo e(config('app.url')); ?>/email-flow?tab=delivered">Delivered</a></li>
                <li class="nav-item">
                    <a class="nav-link <?php if(($tab ?? null) === 'bounced'): ?> active <?php endif; ?>"
                       href="<?php echo e(config('app.url')); ?>/email-flow?tab=bounced">Bounced</a>
                </li>
            </ul>
            <div class="table-responsive p-0">
                <table class="table align-items-center" id="clx_datatable">
                    <thead>
                    <tr>
                        <th>Recipient</th>
                        <th>Subject</th>
                        <th>Status</th>
                        <th class="text-right">Date & Time</th>
                        <th class="text-right">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $marketing_emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing_email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($marketing_email->email); ?>

                            </td>
                            <td>
                                <?php echo e($marketing_email->subject); ?>

                            </td>
                            <td>
                                <?php if(!$marketing_email->sent): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($marketing_email->bounced): ?>
                                    <span class="badge badge-danger">Bounced</span>
                                <?php elseif($marketing_email->sent): ?>
                                    <span class="badge badge-success">Delivered</span>
                                <?php else: ?>
                                    --
                                <?php endif; ?>
                            </td>
                            <td class="text-right">
                                <?php echo e($marketing_email->created_at->format('M d, h:i A')); ?>

                            </td>
                            <td class="text-right">

                                <a class="btn btn-link text-danger text-gradient px-3 mb-0" href="/delete/contact/"><i class="far fa-trash-alt me-2"></i>Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>





        </div>
    </div>

<?php $__env->startSection('script'); ?>

    <script>

        $(function () {
            $('#clx_datatable').dataTable(
                {
                    responsive: true,
                    lengthChange: false,
                }
            );
        });

    </script>

<?php $__env->stopSection(); ?>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/marketing/email-flow.blade.php ENDPATH**/ ?>