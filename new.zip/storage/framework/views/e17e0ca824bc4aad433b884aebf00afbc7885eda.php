<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="font-weight-bolder"><?php echo e(__('PESTLE Analysis')); ?></h4>
                    <hr>
                    <form method="post" action="/save-pestel">
                        <?php if($errors->any()): ?>
                            <div class="alert bg-pink-light text-danger">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">
                                <?php echo e(__('Business/Company Name')); ?>

                            </label><label class="text-danger">*</label>
                            <input class="form-control" name="company_name" id="company_name"

                                   <?php if(!empty($model)): ?>
                                   value="<?php echo e($model->company_name); ?>"
                                <?php endif; ?>
                            >

                        </div>
                        <div class="row mt-4">
                            <div class="col align-self-end">
                                <div class="col align-self-center">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">
                                            <?php echo e(__('Political')); ?>

                                        </label>
                                        <p class="form-text text-muted text-xs ms-1">
                                            <?php echo e(__('What are the political factors relate to how the government intervenes in the economy?')); ?>


                                        </p>
                                        <textarea class="form-control mt-4" rows="10" id="political"
                                                  name="political"><?php if(!empty($model)): ?><?php echo e($model->political); ?><?php endif; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center">
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">
                                        <?php echo e(__('Economic')); ?>

                                    </label>
                                    <p class="form-text text-muted text-xs ms-1">
                                        <?php echo e(__('What are the economic factors include economic growth, exchange rates, inflation rate, and interest rates. ')); ?>


                                    </p>
                                    <textarea class="form-control mt-4" rows="10" id="economic"
                                              name="economic"><?php if(!empty($model)): ?><?php echo e($model->economic); ?><?php endif; ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col align-self-end">
                                <div class="col align-self-center">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">
                                            <?php echo e(__('Social')); ?>

                                        </label>
                                        <p class="form-text text-muted text-xs ms-1">
                                            <?php echo e(__('What are the social factors include the cultural aspects and health consciousness, population growth rate, age distribution, career attitudes and emphasis on safety?')); ?>

                                        </p>
                                        <textarea class="form-control mt-4" rows="10" id="social"
                                                  name="social"><?php if(!empty($model)): ?><?php echo e($model->social); ?><?php endif; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center">
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">
                                        <?php echo e(__('Technological')); ?>

                                    </label>
                                    <p class="form-text text-muted text-xs ms-1">
                                        <?php echo e(__('What are the technological factors include technological aspects like R&D activity, automation, technology incentives and the rate of technological change?')); ?>

                                    </p>
                                    <textarea class="form-control mt-4" rows="10" id="technological"
                                              name="technological"><?php if(!empty($model)): ?><?php echo e($model->technological); ?><?php endif; ?></textarea>
                                </div>
                            </div>
                        </div>
                            <div class="row mt-4">

                                <div class="col align-self-center">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">
                                            <?php echo e(__('Legal')); ?>

                                        </label>
                                        <p class="form-text text-muted text-xs ms-1">
                                            <?php echo e(__('Legal factors are those that emerge from changes to the regulatory environment, which may affect the broader economy, certain industries, or even individual businesses within a specific sector. ')); ?>

                                        </p>
                                        <textarea class="form-control mt-4" rows="10" id="legal"
                                                  name="legal"><?php if(!empty($model)): ?><?php echo e($model->legal); ?><?php endif; ?></textarea>
                                    </div>
                                </div>
                                <div class="col align-self-end">
                                    <div class="col align-self-center">
                                        <div class="form-group">
                                            <label for="exampleFormControlTextarea1">
                                                <?php echo e(__('Environmental')); ?>

                                            </label>
                                            <p class="form-text text-muted text-xs ms-1">
                                                <?php echo e(__('Environmental factors emerged as a sensible addition to the original PEST framework as the business community began to recognize that changes to our physical environment can present material risks and opportunities for organizations.')); ?>

                                            </p>
                                            <textarea class="form-control mt-4" rows="10" id="environmental"
                                                      name="environmental"><?php if(!empty($model)): ?><?php echo e($model->environmental); ?><?php endif; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php if($model): ?>
                            <input type="hidden" name="id" value="<?php echo e($model->id); ?>">
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-info mt-4" type="submit"><?php echo e(__('Save')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        (function(){
            "use strict";
            tinymce.init({
                selector: '#political',
                plugins: 'lists,table',
                toolbar: 'numlist bullist',
                lists_indent_on_tab: false,
                branding: false,
            });
            tinymce.init({
                selector: '#social',
                plugins: 'lists,table',
                toolbar: 'numlist bullist',
                lists_indent_on_tab: false,
                branding: false,
            });
            tinymce.init({
                selector: '#technological',
                plugins: 'lists,table',
                toolbar: 'numlist bullist',
                lists_indent_on_tab: false,
                branding: false,
            });
            tinymce.init({
                selector: '#economic',
                plugins: 'lists,table',
                toolbar: 'numlist bullist',
                lists_indent_on_tab: false,
                branding: false,
            });
            tinymce.init({
                selector: '#legal',
                plugins: 'lists,table',
                toolbar: 'numlist bullist',
                lists_indent_on_tab: false,
                branding: false,
            });
            tinymce.init({
                selector: '#environmental',
                plugins: 'lists,table',
                toolbar: 'numlist bullist',
                lists_indent_on_tab: false,
                branding: false,
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/asbwo9e2/trately.com/resources/views/pestel/write-pest.blade.php ENDPATH**/ ?>