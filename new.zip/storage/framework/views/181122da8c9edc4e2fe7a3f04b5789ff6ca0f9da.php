<?php $__env->startSection('content'); ?>

    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-xl-7">
                <div class="card">

                    <div class="card-body p-3 mt-2">
                        <div class="tab-content" id="v-pills-tabContent">
                            <div class="tab-pane fade show position-relative active height-400 border-radius-lg" id="cam1" role="tabpanel" aria-labelledby="cam1" style="background-image: url('/work.jpg'); background-size:cover;">
                                <div class="overflow-hidden position-relative border-radius-lg bg-cover h-100" style="background-image: url('/work.jpg');">
                                    <span class="mask bg-gradient-dark"></span>
                                    <div class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3">
                                        <h5 class="text-white font-weight-bolder mb-4 pt-2">Today's HighLight<span class="float-end"><a  href="/add-task" class="btn btn-outline-white rounded-circle p-2 mx-2 mb-0" type="button" data-bs-toggle="tooltip" data-bs-placement="top" title="Pause">
                                                <i class="fas fa-plus p-2"></i>
                                            </a></span></h5>
                                        <ul class="list-group list-group-flush" data-toggle="checklist">
                                            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <div class="checklist-item checklist-item-primary ps-2 ms-3 mb-3">
                                                    <div class="d-flex align-items-center">
                                                        <div class="form-check">
                                                            <input class="form-check-input  todo_checkbox" type="checkbox"
                                                                   data-id="<?php echo e($todo->id); ?>"

                                                                   <?php if($todo->completed): ?> checked <?php endif; ?>

                                                            >
                                                        </div>
                                                        <h6 class="mb-0 text-white font-weight-bold text-sm"><?php echo e($todo->title); ?></h6>

                                                    </div>

                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </ul>
                                        <div class="d-flex mt-5">

                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 ms-auto mt-xl-0 mt-4">
                <div class="row">
                    <div class="col-12">
                        <div class="card bg-gradient-dark">
                            <div class="card-body p-3">
                                <div class="row">
                                    <div class="col-8 my-auto">
                                        <div class="numbers">
                                            <p class="text-white text-sm mb-0 text-capitalize font-weight-bold opacity-7"></p>
                                            <h6 class="text-white font-weight-bolder mb-0">
                                                <?php echo e($date->toRfc850String()); ?>

                                            </h6>
                                        </div>
                                    </div>
                                    <div class="col-4 text-end">

                                        <h5 class="mb-0 text-white text-end me-1"></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h1 class="text-gradient text-dark"><span id="status1" countto="21"><?php echo e($total_goals); ?></span> </h1>
                                <h6 class="mb-0 font-weight-bolder">Goals</h6>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mt-md-0 mt-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h1 class="text-gradient text-dark"> <span id="status2" countto="44"><?php echo e($total_plans); ?></span></h1>
                                <h6 class="mb-0 font-weight-bolder">Plans</h6>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h1 class="text-gradient text-dark"><span id="status3" countto="87"><?php echo e($total_notes); ?></span></h1>
                                <h6 class="mb-0 font-weight-bolder">Notes</h6>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mt-md-0 mt-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h1 class="text-gradient text-dark"><span id="status4" countto="417"><?php echo e($total_projects); ?></span></h1>
                                <h6 class="mb-0 font-weight-bolder">Projects</h6>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header pb-0 p-3">
                <div class="d-flex align-items-center">
                    <h6 class="mb-0">Recent Projects</h6>

                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-items-center mb-0">
                    <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Project Name</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Start Date</th>

                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">End Date</th>

                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $recent_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div class="avatar avatar-sm me-3 bg-gradient-dark border-radius-md p-2">
                                        <h6 class="text-white"><?php echo e($project->title['0']); ?></h6>
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-xs"><?php echo e($project->title); ?></h6>
                                        <p class="text-xs text-secondary mb-0">richard@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>

                            <td class="align-middle text-center text-sm">
                                <span class="badge bg-gradient-success font-weight-bold"><?php echo e($project->start_date); ?></span>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge bg-gradient-primary font-weight-bold"><?php echo e($project->end_date); ?></span>
                            </td>

                        </tr>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </tbody>
                </table>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-5 ms-auto">
                <div class="card">
                    <div class="card-header pb-0 p-3">
                        <div class="d-flex align-items-center">
                            <h6 class="mb-0">Recent Events</h6>

                        </div>
                    </div>

                    <div class="card">

                        <div class="card-body border-radius-lg p-3">

                            <?php $__currentLoopData = $recent_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="d-flex mt-4">
                                    <div>
                                        <div class="icon icon-shape bg-gradient-faded-light shadow text-center border-radius-md shadow-none">
                                            <i class="ni ni-bell-55 text-lg text-secondary  opacity-10" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                    <div class="ms-3">
                                        <div class="numbers">
                                            <h6 class="mb-1 text-dark text-sm"><?php echo e($event->title); ?></h6>

                                            <span class="text-sm"><?php echo e($event->start_date); ?>---<span class="text-sm"><?php echo e($event->end_date); ?></span></span>




                                        </div>


                                    </div>


                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-7 ">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header pb-0">
                                <h6>Goals</h6>
                            </div>
                            <div class="card-body px-0 pt-0 pb-2">
                                <div class="table-responsive p-0">
                                    <table class="table align-items-center mb-0">
                                        <thead>
                                        <tr>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Estimate Date to finish</th>
                                            <th class="text-center float-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Completed?</th>



                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex px-2 py-1">

                                                        <div class="d-flex flex-column justify-content-center">
                                                            <h6 class="mb-0 text-sm"><a href="/set-goal?id=<?php echo e($goal->id); ?>"><?php echo e($goal->name); ?></a></h6>

                                                        </div>
                                                    </div>
                                                </td>
                                                <td>

                                                    <span class="text-xs font-weight-bold"><?php echo e($goal->date); ?></span>

                                                </td>

                                                <td class="align-right text-sm">
                                                    <div class="form-check float-end ">
                                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked>

                                                    </div>
                                                </td>


                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script>
        $(function () {
            $('.todo_checkbox').on('change',function () {
                let that = $(this);
                if(this.checked)
                {
                    $.post('/todos/change-status',{
                        id: that.attr('data-id'),
                        status: 'Completed',
                        _token: '<?php echo e(csrf_token()); ?>',
                    });
                }
                else{
                    $.post('/todos/change-status',{
                        id: that.attr('data-id'),
                        status: 'Not Completed',
                        _token: '<?php echo e(csrf_token()); ?>',
                    });
                }
            });
        });
    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/dashboard.blade.php ENDPATH**/ ?>