<?php $__env->startSection('content'); ?>


    <div class="card mb-3 mt-4">

        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">
                    <h6 class="mb-0">Broadcast SMS</h6>
                </div>
                <div class="col-md-6 text-right">
                    <a class="btn bg-gradient-dark mb-0" href="/sms-campaigns">&nbsp;&nbsp;Go to SMS campaign</a>
                </div>
            </div>
        </div>
        <div class="card-body  p-3">
            <form action="/sms-broadcast" method="post">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Send To the Audience</label>
                    <select class="form-select" aria-label="Default select example" name="audience_id">
                        <?php $__currentLoopData = $audiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($audience->id); ?>"
                                    <?php if(!empty($broadcast_sms)): ?>
                                    <?php if($broadcast_sms->audience_id == $audience->id): ?>
                                    selected
                                <?php endif; ?>
                                <?php endif; ?>
                            ><?php echo e($audience->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>


                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Search a Contact To Preview</label>
                    <select class="form-select" aria-label="Default select example" name="contact_id">
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($contact->id); ?>"
                                    <?php if(!empty($broadcast_sms)): ?>
                                    <?php if($broadcast_sms->contact_id == $contact->id): ?>
                                    selected
                                <?php endif; ?>
                                <?php endif; ?>
                            ><?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>






                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($broadcast_sms->id); ?>">

                <button class="btn btn-primary" type="submit">Confirm and Queue Sending</button>

            </form>

        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/marketing/broadcast-sms.blade.php ENDPATH**/ ?>