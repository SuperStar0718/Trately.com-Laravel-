<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header pb-0 px-3">


        </div>
        <form action="/save-note" method="post">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Title</label>
                    <input type="text" name="title" <?php if(!empty($note)): ?> value="<?php echo e($note->title); ?>"<?php endif; ?> class="form-control" id="exampleFormControlInput1" >
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Topic/Subject</label>
                    <input type="text" name="topic" <?php if(!empty($note)): ?> value="<?php echo e($note->topic); ?>"<?php endif; ?>  class="form-control" id="exampleFormControlInput1" >
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Write Notes</label>
                    <textarea class="form-control" name="notes" id="notes" rows="20"><?php if(!empty($note)): ?><?php echo e($note->notes); ?><?php endif; ?></textarea>
                </div>
                <?php echo csrf_field(); ?>
                <?php if($note): ?>
                    <input type="hidden" name="id" value="<?php echo e($note->id); ?>">
                <?php endif; ?>
                <button class="btn btn-primary" type="submit">Save</button>
            </div>

        </form>


    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        tinymce.init({
            selector: '#notes',


            plugins: 'table,code,advlist',


        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/actions/add-note.blade.php ENDPATH**/ ?>