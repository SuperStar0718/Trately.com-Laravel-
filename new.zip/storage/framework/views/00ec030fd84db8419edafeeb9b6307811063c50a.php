<?php $__env->startSection('content'); ?>




    <div class=" row">
        <div class="col">
            <h5 class=" text-secondary fw-bolder">
                <?php echo e(__('Email Settings')); ?>

            </h5>
        </div>
        <div class="col text-end">
        </div>
    </div>



    <div class="row mb-5">
        <div class="  col-md-8 mt-lg-0 mt-4">
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" action="/save-email-setting" method="post">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="mt-4" id="basic-info">
                            <div class=" pt-0">
                                <div class="row mb-4">
                                    <label class="form-label"><?php echo e(__('SMTP Host')); ?></label>

                                    <div class="input-group">
                                        <input id="host" name="smtp_host" value="<?php echo e($settings['smtp_host'] ?? ''); ?>"
                                               class="form-control" type="text" required="required">
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <label class="form-label"><?php echo e(__('SMTP Username')); ?></label>

                                    <div class="input-group">
                                        <input id="username" name="smtp_username" value="<?php echo e($settings['smtp_username'] ?? ''); ?>"
                                               class="form-control" type="text" required="required">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label class="form-label"><?php echo e(__('SMTP Password')); ?></label>

                                    <div class="input-group">
                                        <input id="password" name="smtp_password" value="<?php echo e($settings['smtp_password'] ?? ''); ?>"
                                               class="form-control" type="text" required="required">
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label class="form-label"><?php echo e(__('SMTP Port')); ?></label>

                                    <div class="input-group">
                                        <input id="port" name="smtp_port" value="<?php echo e($settings['smtp_port'] ?? ''); ?>"
                                               class="form-control" type="number" required="required">
                                    </div>
                                </div>



                                <?php echo csrf_field(); ?>
                                <button class="btn btn-info btn-sm float-left mt-4 mb-0"><?php echo e(__('Update')); ?> </button>
                            </div>
                        </div>
                    </form>

                </div>

            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super-admin-portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/startup-kit/resources/views/super-admin/email-settings.blade.php ENDPATH**/ ?>