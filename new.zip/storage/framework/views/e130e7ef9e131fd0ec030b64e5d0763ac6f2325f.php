<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
           5 Minute Daily Journal/ Meditation
            <p class="form-text text-muted text-xs ms-1">Have a concious intentional coversation with yourself</p>
            <p>Start your day by saying</p>
            <h4>Today is going to be a great day</h4>

        </div>




        <div class="card-body">
            <form action="/save-journal" method="post">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="example-date-input" class="form-control-label">Today's Date</label><span class="text-danger">*</span>
                    <input class="form-control"  name="date" type="date" value="<?php echo e(date('Y-m-d')); ?>" id="date"
                           <?php if(!empty($journal)): ?>
                           value="<?php echo e($journal->date); ?>"
                           <?php else: ?>
                           value="{date('Y/m/d')}"
                        <?php endif; ?>>
                </div>






                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"> 2 Things I am grateful for </label>
                            <p class="form-text text-muted text-xs ms-1">

                                Write 2 to 3 things you are grateful for. Gratitude has tremendous effect on your well-being.
                            </p>
                            <textarea name="grateful" class="form-control" id="grateful" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->grateful); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">What would make me feel great today</label> <p class="form-text text-muted text-xs ms-1">
                                Write 2 to 3 things that would make you feel great such as taking a long walk or reading a book with a warm cup of tea or coffee.
                            </p>
                            <textarea class="form-control" id="feeling" name="feeling" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->feeling); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Daily Affirmations</label>
                            <p class="form-text text-muted text-xs ms-1">
                                Write positive affirmations such as I am Capable of making my dreams come ture, I am worthy of Greatness.
                            </p>
                            <textarea class="form-control" name="affirmations" id="affirmations" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->affirmations); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Favorite Things of my day</label>                <p class="form-text text-muted text-xs ms-1">
                                Write 2 to 3 favorite things of your day such as after a busy workday you like to take a long shower with scented shower gel. Talking to your friends and family. Coming up with awesome ideas.Etc.
                            </p>
                            <textarea class="form-control" name="fav_things" id="fav_things" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->fav_things); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">What can i do today that will bring me closer to my dream</label>
                            <p class="form-text text-muted text-xs ms-1">
                                Write a short note on what actions can you take today that will bring you closer to your goals. That could be that you want to lose weight so today you can do a 20 minute exercise, or you want to start a new company you can study about how can you register a company. Etc. The more specific your though the nearer you are to accomplish your dreams.
                            </p>
                            <textarea class="form-control" name="dream" id="dream" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->dream); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">What positive habit i have developed</label>     <p class="form-text text-muted text-xs ms-1">
                                Did you develop any positive habit such as waking up early, stop wasting time on social media etc. If yes, Write those down. Keep track of that. It will save your life.
                            </p>
                            <textarea class="form-control" name="habit" id="habit" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->habit); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">I should not waste time on </label> <p class="form-text text-muted text-xs ms-1">
                                Write the things you dont want to waste your valuable time on such as you might want to not waste time on negative thinking and avoid negative people. You might also want to reduce the amount of time you spend on social media.
                            </p>
                            <textarea class="form-control" name="dont_waste" id="dont_waste" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->dont_waste); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">What are the things i must accomplish today(Non-Negotiable)</label>
                            <p class="form-text text-muted text-xs ms-1">
                                Write the things you must do such as paying certain bills, take a 30 minute walk. Do Five minute meditation, etc.
                            </p>
                            <textarea class="form-control" name="must_accomplish" id="must_accomplish" rows="10"><?php if(!empty($journal)): ?><?php echo e($journal->must_accomplish); ?><?php endif; ?></textarea>
                        </div>

                    </div>
                </div>


                <?php if($journal): ?>
                    <input type="hidden" name="id" value="<?php echo e($journal->id); ?>">
                <?php endif; ?>

                <?php echo csrf_field(); ?>
                <button type="submit" class="btn bg-gradient-secondary">Save</button>
                <button type="button" class="btn bg-gradient-secondary">Close</button>
            </form>


        </div>


    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script>
        $(function () {


            flatpickr("#date", {

                dateFormat: "Y-m-d",
            });




        });


    </script>
    <script>

        tinymce.init({
            selector: '#grateful',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#feeling',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#affirmations',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#fav_things',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#dream',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#habit',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#dont_waste',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
        tinymce.init({
            selector: '#must_accomplish',

            plugins: 'lists,table',
            toolbar: 'numlist bullist',
            lists_indent_on_tab: false


        });
    </script>

<?php $__env->stopSection(); ?>













<?php echo $__env->make('layouts.marketing_crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/gratitude/five-min-journal.blade.php ENDPATH**/ ?>