

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>
        <?php echo e($settings['company_name']); ?>

    </title>


    <!-- Nucleo Icons -->
    <link id="pagestyle" href="/css/app.css?v=26" rel="stylesheet" />
    <!-- Anti-flicker snippet (recommended)  -->
    <style>
        .async-hide {
            opacity: 0 !important
        }
    </style>


</head>

<body class="g-sidenav-show  bg-gray-100">
<!-- Extra details for Live View on GitHub Pages -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Navbar -->

<!-- End Navbar -->
<section class="min-vh-100 mb-8">
    <div class="page-header align-items-start min-vh-50 pt-5 pb-11 m-3 border-radius-lg" style="background-image: url('../assets/img/curved-images/curved14.jpg');">
        <span class="mask bg-gradient-dark opacity-6"></span>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 text-center mx-auto">
                    <h1 class="text-white mb-2 mt-5"><?php echo e($form->header_title); ?></h1>
                    <p class="text-lead text-white"><?php echo e($form->header_text); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-lg-n10 mt-md-n11 mt-n10">
            <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
                <div class="card z-index-0">


                    <div class="card-body">

                        <?php echo $__env->make('form-fields.generate-lead-capture-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <button type="Submit" class="btn btn-dark">Submit</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


</body>

</html>
<?php /**PATH /Users/sadia/Documents/valet/marketing-crm/resources/views/contacts/public-form.blade.php ENDPATH**/ ?>