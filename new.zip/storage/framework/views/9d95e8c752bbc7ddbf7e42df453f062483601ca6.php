<?php $__env->startSection('content'); ?>

    <div class="">
        <div class="col-lg-12 mx-auto">
            <div class="card card-body ">

                <div class="page-header mb-4 border-radius-xl">
                    <span class="mask bg-purple-light"></span>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 mt-6 mb-6 text-center my-auto">

                                <h3 class="text-dark">
                                    <?php echo e($plan->company_name); ?>

                                </h3>

                                <h2 class="text-purple display-3 fadeIn2 fadeInBottom mt-4 mb-4"><?php echo e(__('Business Plan')); ?></h2>
                                <h5 class="text-muted fadeIn2 fadeInBottom">
                                    <?php if(!empty($plan->date)): ?>
                                        <?php echo e($plan->date->format(config('app.date_format'))); ?>

                                    <?php endif; ?>

                                </h5>

                            </div>

                        </div>

                    </div>
                </div>

                <div class="mt-4 text-center mt-8 mb-7">

                    <h5 class=" fadeIn2 fadeInBottom"><?php echo e(__('Prepared By')); ?></h5>
                    <h3><?php echo e($plan->name); ?></h3>

                    <h6 class="text-muted"><?php echo e($plan->email); ?></h6>
                </div>


                    <?php if($plan->ex_summary): ?>

                    <div class="text-center mt-8">
                        <h6><?php echo e(__('Executive Summary')); ?></h6>


                    </div>
                    <div>
                        <?php echo $plan->ex_summary; ?>




                    </div>
                <?php endif; ?>


                 <?php if($plan->description): ?>
                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Company description')); ?></h6>
                    </div>
                    <?php echo $plan->description; ?>


                <?php endif; ?>




                <?php if($plan->m_analysis): ?>

                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Market Analysis')); ?></h6>
                    </div>
                    <?php echo $plan->m_analysis; ?>


                <?php endif; ?>


                <?php if($plan->management): ?>

                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Organization & Management')); ?></h6>
                    </div>
                    <?php echo $plan->management; ?>



                <?php endif; ?>


                <?php if($plan->product): ?>

                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Service or product')); ?></h6>
                    </div>
                    <?php echo $plan->product; ?>



                <?php endif; ?>


                <?php if($plan->marketing): ?>

                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Marketing and sales')); ?></h6>
                    </div>
                    <?php echo $plan->marketing; ?>


                <?php endif; ?>



                <?php if($plan->budget): ?>
                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Budget')); ?></h6>
                    </div>
                    <?php echo $plan->budget; ?>


                <?php endif; ?>


                <?php if( $plan->investment ): ?>


                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Investment/Funding request')); ?></h6>
                    </div>
                    <?php echo $plan->investment; ?>




                <?php endif; ?>



                <?php if($plan->finance): ?>

                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Financial projections')); ?></h6>
                    </div>
                    <?php echo $plan->finance; ?>



                <?php endif; ?>

                <?php if($plan->appendix): ?>

                    <div class="text-center mt-4">
                        <h6><?php echo e(__('Appendix')); ?></h6>
                    </div>
                    <?php echo $plan->appendix; ?>


                <?php endif; ?>



                </div>



            </div>

        </div>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus-saas/resources/views/plans/view-business-plan.blade.php ENDPATH**/ ?>