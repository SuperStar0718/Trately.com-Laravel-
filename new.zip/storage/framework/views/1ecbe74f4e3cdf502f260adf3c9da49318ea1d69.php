<?php $__env->startSection('content'); ?>
    <div class="row d-print-none">
        <div class="col  text-center">
            <h5 class="mb-2 text-secondary fw-bolder">
                <?php echo e(__('SWOT Analysis of')); ?>

                <?php if(!empty($model)): ?>
                    <?php echo e($model->company_name); ?>

                <?php endif; ?>

            </h5>
        </div>

    </div>
    <div class="row mt-3">
        <div class="col-lg-1 col-md-1 pt-5 pt-lg-0 ms-lg-2 text-center d-print-none">


            <a href="/write-swot?id=<?php echo e($model->id); ?>" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="right" title="Edit">
                <i class="fas fa-pen p-2"></i>
            </a>
            <a href="#" onclick="window.print()" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="Print">
                <i class="fas fa-print p-2"></i>
            </a>
            <a href="/swot-list" class="btn btn-white border-radius-lg p-2 mt-2" type="button" data-bs-toggle="tooltip" data-bs-placement="left" title="List">
                <i class="fas fa-ellipsis-h p-2"></i>
            </a>
        </div>

        <div class="col-md-10">

            <div class="card-group">
                <div class="card">
                    <div class="card-header fw-bolder  text-purple bg-purple-light border-success">
                        <h1 class="text-purple">S</h1>
                        <?php echo e(__('Strengths')); ?>

                    </div>
                    <div class="card-body">
                        <p>
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->strengths); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder  text-danger bg-pink-light border-success">
                        <h1 class="text-danger">W</h1>
                        <?php echo e(__('Weaknesses')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->weaknesses); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder  text-success bg-success-light border-success">
                        <h1 class="text-success">O</h1>
                        <?php echo e(__('Opportunities')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->opportunities); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header fw-bolder text-warning bg-warning-light border-success">
                        <h1 class="text-warning">T</h1>
                        <?php echo e(__('Threats')); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <?php if(!empty($model)): ?>
                                <?php echo clean($model->threats); ?>

                            <?php endif; ?>

                        </p>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/asbwo9e2/trately.com/resources/views/swot/view-swot.blade.php ENDPATH**/ ?>