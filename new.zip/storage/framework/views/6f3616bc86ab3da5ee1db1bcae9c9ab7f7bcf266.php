<?php $__env->startSection('content'); ?>

    <h3><?php echo e(__('Database Info')); ?></h3>

    <?php if($has_error): ?>
        <p class="text-danger">
            <?php echo e(__('Unable to connect the Database. Try Again.')); ?>


        </p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('db.installation')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="db_host"><?php echo e(__('Database Host')); ?></label>
            <input type="text" class="form-control" id="db_host" name = "DB_HOST" required autocomplete="off">
            <input type="hidden" name = "types[]" value="DB_HOST">
        </div>
        <div class="mb-3">
            <label for="db_name"><?php echo e(__('Database Name')); ?></label>
            <input type="text" class="form-control" id="db_name" name = "DB_DATABASE" required autocomplete="off">
            <input type="hidden" name = "types[]" value="DB_DATABASE">
        </div>
        <div class="mb-3">
            <label for="db_user"><?php echo e(__('Database Username')); ?></label>
            <input type="text" class="form-control" id="db_user" name = "DB_USERNAME" required autocomplete="off">
            <input type="hidden" name = "types[]" value="DB_USERNAME">
        </div>
        <div class="mb-3">
            <label for="db_pass"><?php echo e(__('Database Password')); ?></label>
            <input type="password" class="form-control" id="db_pass" name = "DB_PASSWORD" autocomplete="off">
            <input type="hidden" name = "types[]" value="DB_PASSWORD">
        </div>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Continue')); ?></button>
    </form>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadia/Documents/valet/focus/resources/views/install/step2.blade.php ENDPATH**/ ?>